
<!-- inclusion meta -->
@include('inc.head.meta')
<!-- inclusion css -->
  @include('inc.head.css')
