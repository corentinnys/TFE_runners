<div class="row g-row-col--0">
  @foreach($users as $user)
    <div class="col-md-3 col-xs-6 g-full-width--xs">
        <div class="wow fadeInUp" data-wow-duration=".3" data-wow-delay=".1s">
            <!-- Team -->
            <div class="s-team-v1">
                <img class="img-responsive g-width-100-percent--xs" src="{{asset('img/400x400/03.jpg')}}" alt="Image">
                <div class="g-text-center--xs g-bg-color--white g-padding-x-30--xs g-padding-y-40--xs">
                    <h2 class="g-font-size-18--xs g-margin-b-5--xs">{{$user->name}}</h2>
                    <span class="g-font-size-15--xs g-color--text"><i>poste : meneur</i></span>
                </div>
            </div>
            <!-- End Team -->
        </div>
    </div>
  @endforeach
</div>
