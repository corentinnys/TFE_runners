
<div class="js__parallax-window" style="background: url({{asset('img/1920x1080/03.jpg')}}) 50% 0 no-repeat fixed;">
    <div class="container g-text-center--xs g-padding-y-80--xs g-padding-y-125--sm">
        <div class="g-margin-b-80--xs">
            <h2 class="g-font-size-40--xs g-font-size-50--sm g-font-size-60--md g-color--white">Un club , des équipes , des joueurs et une même passion </h2>
        </div>
    </div>
</div>
