@foreach($equipe as $key=> $item)
    @if($key == 0)
  <div class="s-promo-block-v3 g-bg-position--center g-fullheight--sm" style="background: url({{asset('img/clients/inscription.jpg')}});">
      <div class="container g-ver-center--sm g-padding-y-125--xs g-padding-y-0--sm">
          <div class="g-margin-t-30--xs g-margin-t-0--sm g-margin-b-30--xs g-margin-b-70--md">
              <h1 class="g-font-size-35--xs g-font-size-45--sm g-font-size-50--lg " style="color:#32CD32">{{$item->valeur}}</h1>
          </div>
          <div class="row">
              <div class="col-sm-8 col-sm-push-4 g-margin-b-50--xs g-margin-b-0--md">
                  <div class="s-promo-block-v3__divider g-display-none--xs g-display-block--md"></div>
                  <div class="row">
                      <div class="col-sm-6 g-margin-b-30--xs g-margin-b-0--md">
                          <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".4s">
                              <p style="color:white; font-size:1.2rem">Rejoind une équipe motivé pour te faire évoluer à ton niveau</p>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
@else
  @include('parallax')
  @include('users.all')
  
  @endif


@endforeach
