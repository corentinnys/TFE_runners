<div class="container g-padding-y-50--xs">
    <div class="row">
        <div class="col-xs-6">
            <a href="index.html">
                <img class="g-width-100--xs g-height-auto--xs" src="{{asset('img/logo.png')}}" alt="Megakit Logo">
            </a>
        </div>
        <div class="col-xs-6 g-text-right--xs">
            <p class="g-font-size-14--xs g-margin-b-0--xs g-color--white-opacity-light"><a href="http://keenthemes.com/preview/Megakit/">Megakit</a> Theme Powered by: <a href="http://www.keenthemes.com/">KeenThemes.com</a></p>
        </div>
    </div>
</div>
