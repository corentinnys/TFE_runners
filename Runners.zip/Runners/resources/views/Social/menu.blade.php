<ul class="list-inline s-header__action s-header__action--rb">
    @include('Social.items')
</ul>
