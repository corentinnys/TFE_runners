<div class="col-sm-2 g-margin-b-20--xs g-margin-b-0--md">
    <ul class="list-unstyled g-ul-li-tb-5--xs g-margin-b-0--xs">
      @include('Social.items')
    </ul>
</div>
