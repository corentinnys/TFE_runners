<!--<section class="s-google-map">
    <div id="js__google-container" class="s-google-container g-height-400--xs"></div>
</section>-->

<section>
  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2520.1053249167066!2d4.3491756161199175!3d50.82921297952943!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c3c460e67ba689%3A0x3debb060f351c928!2sInstitut+Pierre+Paulus!5e0!3m2!1sfr!2sbe!4v1506853610765" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
</section>
