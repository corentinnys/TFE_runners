@foreach($itemsSlider as $items)
  <div class="g-fullheight--xs g-bg-position--center swiper-slide" style="background: url('img/1920x1080/01.jpg')">
      <div class="container g-text-center--xs g-ver-center--xs">
          <div class="g-margin-b-30--xs">
              <h1 class="g-font-size-35--xs g-font-size-45--sm g-font-size-55--md g-color--white">{{$items->valeur}}</h1>
          </div>
          <a class="js__popup__youtube" href="https://www.youtube.com/watch?v=lcFYdgZKZxY" title="Intro Video">
              <i class="s-icon s-icon--lg s-icon--white-bg g-radius--circle ti-control-play"></i>
          </a>
      </div>
  </div>
@endforeach
