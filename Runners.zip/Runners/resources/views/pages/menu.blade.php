@inject('user', 'App\Repositories\UserRepository')
<br>
@if(Request::is('home'))

  <ul class="list-unstyled s-header__nav-menu">
    @if($user->verifComite(Session::get('mail'))== true)
      <li>
        <a href="" style="color:white">resumer de la derniere reunion</a>

      </li>
    @endif
        <li >
            <a href="{{ route('logout') }}"
                onclick="event.preventDefault();
                         document.getElementById('logout-form').submit();" style='color:white'>
                Déconnection
            </a>

            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                {{ csrf_field() }}
            </form>
        </li>

  </ul>
@else
<ul class="list-unstyled s-header__nav-menu">

  @foreach($itemsMenu as $items)
    @if($items->nom != "slug")
  <li class="s-header__nav-menu-item">

    <a class="s-header__nav-menu-link s-header__nav-menu-link-divider"

     href="{{URL::to(App::getLocale()."/$items->valeur")}}">

      {{$items->valeur}}
     </a>

   </li>
@endif
  @endforeach
  <li class="s-header__nav-menu-item">

    <a class="s-header__nav-menu-link s-header__nav-menu-link-divider"

     href="{{URL::to('/login')}}">

      Mon espace
     </a>

   </li>
</ul>
@endif
