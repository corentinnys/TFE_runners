@inject('erreur', 'App\Utilities\FormErrors')
<div class="s-promo-block-v3 g-bg-position--center g-fullheight--sm" style="background: url({{asset('img/clients/inscription.jpg')}});">
    <div class="container g-ver-center--sm g-padding-y-125--xs g-padding-y-0--sm">
        <div class="g-margin-t-30--xs g-margin-t-0--sm g-margin-b-30--xs g-margin-b-70--md">
            <h1 class="g-font-size-35--xs g-font-size-45--sm g-font-size-50--lg " style="color:#32CD32">Rejoignez-nous dans <br> notre aventure</h1>
        </div>
        <div class="row">
            <div class="col-sm-8 col-sm-push-4 g-margin-b-50--xs g-margin-b-0--md">
                <div class="s-promo-block-v3__divider g-display-none--xs g-display-block--md"></div>
                <div class="row">
                    <div class="col-sm-6 g-margin-b-30--xs g-margin-b-0--md">
                        <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".4s">
                            <p style="color:white; font-size:1.2rem">Rejoind une équipe motivé pour te faire évoluer à ton niveau</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="g-bg-color--primary-ltr">
    <div class="container g-padding-y-80--xs g-padding-y-125--sm">
        <div class="g-text-center--xs g-margin-b-100--xs">
            <p class="text-uppercase g-font-size-14--xs g-font-weight--700 g-color--white-opacity g-letter-spacing--2 g-margin-b-25--xs">Comment s'inscrire </p>
            <h2 class="g-font-size-32--xs g-font-size-36--md g-color--white"></h2>
        </div>
        <ul class="list-inline row g-margin-b-100--xs">
            <!-- Process -->
            @if(Request::is('FR/Inscription'))
            <li class="col-sm-4 col-xs-6 g-full-width--xs s-process-v1 g-margin-b-60--xs g-margin-b-0--md" >
                <div class="center-block g-text-center--xs">
                    <div class="g-margin-b-30--xs">
                        <span style="background:yellow" class="g-display-inline-block--xs g-width-100--xs g-height-100--xs g-font-size-38--xs g-color--primary g-bg-color--white g-box-shadow__dark-lightest-v4 g-padding-x-20--xs g-padding-y-20--xs g-radius--circle">01</span>
                    </div>
                    <div class="g-padding-x-20--xs">
                        <h3 class="g-font-size-18--xs" style="color:black">Inscription</h3>
                        <p class="" style="color:black">Completez le formulaire d'inscription</p>
                    </div>
                </div>
            </li>
          @else
            <li class="col-sm-4 col-xs-6 g-full-width--xs s-process-v1 g-margin-b-60--xs g-margin-b-0--md" >
                <div class="center-block g-text-center--xs">
                    <div class="g-margin-b-30--xs">
                        <span style="background:yellow" class="g-display-inline-block--xs g-width-100--xs g-height-100--xs g-font-size-38--xs g-color--primary g-bg-color--white g-box-shadow__dark-lightest-v4 g-padding-x-20--xs g-padding-y-20--xs g-radius--circle">01</span>
                    </div>
                    <div class="g-padding-x-20--xs">
                        <h3 class="g-font-size-18--xs" style="color:white">Inscription</h3>
                        <p class="" style="color:white" >Completez le formulaire d'inscription</p>
                    </div>
                </div>
            </li>
          @endif
            <!-- End Process -->

            <!-- Process -->
            @if(!Request::is('FR/Inscription'))
              @if($numberPage == 2 )
                <li class="col-sm-4 col-xs-6 g-full-width--xs s-process-v1 g-margin-b-60--xs g-margin-b-0--md" >
                    <div class="center-block g-text-center--xs">
                        <div class="g-margin-b-30--xs">
                            <span style="background:yellow" class="g-display-inline-block--xs g-width-100--xs g-height-100--xs g-font-size-38--xs g-color--primary g-bg-color--white g-box-shadow__dark-lightest-v4 g-padding-x-20--xs g-padding-y-20--xs g-radius--circle">02</span>
                        </div>
                        <div class="g-padding-x-20--xs">
                            <h3 class="g-font-size-18--xs" style="color:black">Payement de la cotisation</h3>
                            <p class="" style="color:black">Payer la cotision du pour finaliser l'inscription</p>
                        </div>
                    </div>
                </li>
            @else
              <li class="col-sm-4 col-xs-6 g-full-width--xs s-process-v1 g-margin-b-60--xs g-margin-b-0--md" >
                  <div class="center-block g-text-center--xs">
                      <div class="g-margin-b-30--xs">
                          <span style="background:yellow" class="g-display-inline-block--xs g-width-100--xs g-height-100--xs g-font-size-38--xs g-color--primary g-bg-color--white g-box-shadow__dark-lightest-v4 g-padding-x-20--xs g-padding-y-20--xs g-radius--circle">02</span>
                      </div>
                      <div class="g-padding-x-20--xs">
                          <h3 class="g-font-size-18--xs" style="color:white">Payement de la cotisation</h3>
                          <p class="" style="color:white">Payer la cotision du pour finaliser l'inscription</p>
                      </div>
                  </div>
              </li>

              @endif
                @endif
                  @if(Request::is('FR/Inscription'))
                    <li class="col-sm-4 col-xs-6 g-full-width--xs s-process-v1 g-margin-b-60--xs g-margin-b-0--md" >
                        <div class="center-block g-text-center--xs">
                            <div class="g-margin-b-30--xs">
                                <span style="background:yellow" class="g-display-inline-block--xs g-width-100--xs g-height-100--xs g-font-size-38--xs g-color--primary g-bg-color--white g-box-shadow__dark-lightest-v4 g-padding-x-20--xs g-padding-y-20--xs g-radius--circle">02</span>
                            </div>
                            <div class="g-padding-x-20--xs">
                                <h3 class="g-font-size-18--xs" style="color:white">Payement de la cotisation</h3>
                                <p class="" style="color:white">Payer la cotision du pour finaliser l'inscription</p>
                            </div>
                        </div>
                    </li>
                  @endif

            








                @if(!Request::is('FR/Inscription'))
                  @if($numberPage == 3 )
                    <li class="col-sm-4 col-xs-6 g-full-width--xs s-process-v1 g-margin-b-60--xs g-margin-b-0--sm">
                        <div class="center-block g-text-center--xs">
                            <div class="g-margin-b-30--xs">
                                <span class="g-display-inline-block--xs g-width-100--xs g-height-100--xs g-font-size-38--xs g-color--primary g-bg-color--white g-box-shadow__dark-lightest-v4 g-padding-x-20--xs g-padding-y-20--xs g-radius--circle">03</span>
                            </div>
                            <div class="g-padding-x-20--xs">
                                <h3 style="color:black">Recapitulation</h3>
                                <p style="color:black">Recap de l'inscrption</p>
                            </div>
                        </div>
                    </li>
                  @else
            <li class="col-sm-4 col-xs-6 g-full-width--xs s-process-v1 g-margin-b-60--xs g-margin-b-0--sm">
                <div class="center-block g-text-center--xs">
                    <div class="g-margin-b-30--xs">
                        <span class="g-display-inline-block--xs g-width-100--xs g-height-100--xs g-font-size-38--xs g-color--primary g-bg-color--white g-box-shadow__dark-lightest-v4 g-padding-x-20--xs g-padding-y-20--xs g-radius--circle">03</span>
                    </div>
                    <div class="g-padding-x-20--xs">
                        <h3 class="g-font-size-18--xs g-color--white">Recapitulation</h3>
                        <p class="g-color--white-opacity">Recap de l'inscrption</p>
                    </div>
                </div>
            </li>
          @endif
        @else
          <li class="col-sm-4 col-xs-6 g-full-width--xs s-process-v1 g-margin-b-60--xs g-margin-b-0--sm">
              <div class="center-block g-text-center--xs">
                  <div class="g-margin-b-30--xs">
                      <span class="g-display-inline-block--xs g-width-100--xs g-height-100--xs g-font-size-38--xs g-color--primary g-bg-color--white g-box-shadow__dark-lightest-v4 g-padding-x-20--xs g-padding-y-20--xs g-radius--circle">03</span>
                  </div>
                  <div class="g-padding-x-20--xs">
                      <h3 class="g-font-size-18--xs g-color--white">Recapitulation</h3>
                      <p class="g-color--white-opacity">Recap de l'inscrption</p>
                  </div>
              </div>
          </li>
        @endif
            <!-- End Process -->
        </ul>

        <!--<div class="g-text-center--xs">-->
        @if(Request::is('FR/Inscription'))
            <form method="get" action="{{URL::to('FR/Inscription/payement')}}" enctype="multipart/form-data">
              <fieldset>
                <legend>Informations personnels:</legend>
        <div class="form-group">
          <label style="font-size:1.2rem" for="name">nom:</label>
          <input type="text" class="form-control"  id="name" placeholder="Enter votre nom" name="lastname">
          {!! $erreur->formatting($errors->first('lastname'))!!}
        </div>
        <div class="form-group">
          <label style="font-size:1.2rem" for="lastname">prenom:</label>
          <input type="text" class="form-control" id="lastname" placeholder="Enter votre prenom" name="firstname">
          {!! $erreur->formatting($errors->first('firstname'))!!}
        </div>
        <div style="font-size:1.2rem" class="form-group">
          <label style="font-size:1.2rem" for="ddn">Date de naissance</label>
          <input type="date" class="form-control" id="ddn" placeholder="Votre date de naissance" name="ddn">
          {!! $erreur->formatting($errors->first('ddn'))!!}
        </div>
        <div class="form-group">
          <label style="font-size:1.2rem" for="nationnality">Nationnalite:</label>
          <select class="form-control" name="nationnality" id="nationnality">
          <option value='BE'>Belge</option>
          <option value="FR">Français</option>
          <option value="AL">Allemand</option>
        </select>
        {!! $erreur->formatting($errors->first('nationnality'))!!}
        </div>
        <div class="form-group">
          <label style="font-size:1.2rem" for="nationnal">Numero de registre nationnale</label>
          <input type="text" class="form-control" id="nationnal" placeholder="Entrer votre numero de registre nationnal" name="nationalRegister">
          {!! $erreur->formatting($errors->first('nationalRegister'))!!}
        </div>
        <div class="form-group">
          <label  style="font-size:1.2rem"for="email">Adresse mail</label>
          <input type="text" class="form-control" id="email" placeholder="toto@gmail.com" name="email">
          {!! $erreur->formatting($errors->first('email'))!!}
        </div>
        <div class="form-group">
          <label style="font-size:1.2rem" for="fix">Telephonne fixe</label>
          <input type="tel" class="form-control" id="fix" name="phone">
          {!! $erreur->formatting($errors->first('phone'))!!}
        </div>
        <div class="form-group">
          <label style="font-size:1.2rem" for="smartphone">Votre numero de gsm</label>
          <input type="tel" class="form-control" id="date" placeholder="" name="smartphone">
            {!! $erreur->formatting($errors->first('smartphone'))!!}
        </div>
        <div class="form-group">
          <label style="font-size:1.2rem" for="nbEnfants">Nombre d'enfants </label>
          <input type="number" class="form-control" id="nbEnfants" placeholder="" name="nbEnfants">
            {!! $erreur->formatting($errors->first('nbEnfants'))!!}
        </div>
        <div class="form-group">
          <label style="font-size:1.2rem" for="userPhoto">uploader votre photo </label>
          <input type="file" class="form-control" id="userPhoto" name="photo">
            {!! $erreur->formatting($errors->first('photo'))!!}
        </div>
      </fieldset>
        <fieldset>
          <legend>Deplacements:</legend>
          <div class="checkbox">
            <label>
              <input type="checkbox" checked data-toggle="toggle">Avez-vous un véhicule ?
            </label>
              <!--<input type="checkbox" name="remember" style="font-size:1.2rem"> -->
          </div>
          <div class="checkbox">
            <label>
              <input type="checkbox" checked data-toggle="toggle">Avez-vous la possibilité de conduire plusieurs enfants
              lors des matchs à l’extérieur ?
            </label>
          </div>
        </fieldset>
        <fieldset>
          <legend>Informations complementaire:</legend>
          <div class="form-group">
            <label for="comment">Informations Complementaires:</label>
            <textarea class="form-control" rows="5" id="comment"></textarea>
          </div>
          </fieldset>
        <button type="submit" class="btn btn-primary btn-lg btn-block">Suivant</button>
      </form>
    @elseif(Request::is('FR/Inscription/payement'))
          <h2 class="g-font-size-40--xs g-font-size-50--sm g-font-size-30--md">Selectionner votre mode de payement</h2>
        <fieldset>
          <ul class="nav nav-pills">
            <li class="active">
              <a data-toggle="pill" href="#visa">
                <img src="{{asset('img/clients/visa.png')}}" style="width:50%">
              </a>
            </li>
            <li style="font-size:3rem">Prix : 170 Euros</li>
          </ul>
          <div class="tab-content">
            <div id="visa" class="tab-pane fade in active">
              <form method="get" action="{{URL::to('FR/Inscription/confirmation')}}">
                <legend> Votre carte:</legend>
                <div class="form-group">
                  <label style="font-size:1.2rem" for="carteNumber">numero de carte </label>
                  <input type="text" class="form-control" id="fix" name="carteNumber">
                </div>
                <div class="form-group">
                  <label style="font-size:1.2rem" for="carteNumber">Date d'expiration </label>
                  <input type="text" class="form-control" id="fix">
                </div>
                  <button type="submit" class="btn btn-primary btn-lg btn-block">Finaliser</button>
              </form>
            </div>
          </div>
        </div>
        </fieldset>
        @elseif(Request::is('FR/Inscription/confirmation'))

      <section>
        <h1>Récapitulation de votre inscription aux runners</h1>
        <p>Afin d'etre totalement affiler aux club , veillez telecharger le certificat médical ou celui recu par mail et merci de le faire remplir
          par votre medecin traitant afin que votre inscription soit réélement prise en compte au seins de la fédération </p>
          <button type="button" class="btn btn-success">
            <a href="{{URL::to('FR/Inscription/telechargement/certificat')}}" style="color:white">
              télécharger le certificat médical
            </a>
          </button>
      </section>

      @endif
      <!--  </div>-->
    </div>
</div>
