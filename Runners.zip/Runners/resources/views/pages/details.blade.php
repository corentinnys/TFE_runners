
@extends('Template.Base')
@section('title')
  titre
@stop
@section('content')
  @if(Request::is('FR/Evenements'))
    @include('pages.events')
  @elseif(Request::is('FR/equipes/u14'))
      @include('team.details',['equipe'=>$equipe])
  @elseif(Request::is('FR/Comite'))
    @include('users.all')
  @elseif(Request::is('FR/Inscription'))
    @include('pages.Inscription')
  @elseif(Request::is('FR/Inscription/payement'))
    @include('pages.Inscription',['numberPage'=> $numberPage ])
  @elseif(Request::is('FR/Inscription/confirmation'))
    @include('pages.Inscription',['numberPage'=> 3 ])
  @elseif(Request::is('FR/MonEspace'))
    @include('pages.personnel')
  @elseif(Request::is('FR/Saison'))
    @include('widgets.calendar')
  @elseif(Request::is('FR/EspacePero'))
    <div class="s-promo-block-v3 g-bg-position--center g-fullheight--sm" style="background: url({{asset('img/clients/connection.jpg')}});">
        <div class="container g-ver-center--sm g-padding-y-125--xs g-padding-y-0--sm">
            <div class="g-margin-t-30--xs g-margin-t-0--sm g-margin-b-30--xs g-margin-b-70--md">
                <h1 class="g-font-size-35--xs g-font-size-45--sm g-font-size-50--lg g-color--white">Page de connection<br> à mon espace personnel<br></h1>
            </div>
            <div class="row">
                <div class="col-sm-8 col-sm-push-4 g-margin-b-50--xs g-margin-b-0--md">
                    <div class="s-promo-block-v3__divider g-display-none--xs g-display-block--md"></div>
                    <div class="row">
                        <div class="col-sm-6 g-margin-b-30--xs g-margin-b-0--md">
                            <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".4s">
                              <form method="post" action="{{URL('FR/MonEspace')}}">
                                <div class="form-group">
                                    <label for="mail" style='color:white'>Entrez votre Adresse mail:</label>
                                    <input type="text" name="mail" class="form-control" id="mail" placeholder="toto@gmail.com">
                                  </div>
                                <div class="form-group">
                                    <label for="mail" style='color:white'>Entrez votre mot de passe:</label>
                                    <input type="password" name="pass" class="form-control" id="mail">
                                  </div>
                                <button type="submit" class="btn btn-primary">Connection</button>
                              </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    @include('parallax')

  @endif
@stop
