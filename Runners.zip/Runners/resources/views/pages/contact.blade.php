<form>
    <div class="row g-margin-b-40--xs">
        <div class="col-sm-6 g-margin-b-20--xs g-margin-b-0--md">
            <div class="g-margin-b-20--xs">
                <input type="text" class="form-control s-form-v2__input g-radius--50" placeholder="* Votre nom">
            </div>
            <div class="g-margin-b-20--xs">
                <input type="email" class="form-control s-form-v2__input g-radius--50" placeholder="* Votre mail">
            </div>
            <input type="text" class="form-control s-form-v2__input g-radius--50" placeholder="* votre numero de telephone">
        </div>
        <div class="col-sm-6">
            <textarea class="form-control s-form-v2__input g-radius--10 g-padding-y-20--xs" rows="8" placeholder="* Votre Message"></textarea>
        </div>
    </div>
    <div class="g-text-center--xs">
        <button type="submit" class="text-uppercase s-btn s-btn--md s-btn--primary-bg g-radius--50 g-padding-x-80--xs">Contactez-nous</button>
    </div>
</form>
