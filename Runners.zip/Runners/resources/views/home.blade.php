@extends('Template.Base')

@section('content')
  
@if( Auth::user()->isJoueur == 1 )
  @include('layouts.joueur')
@endif
@endsection
