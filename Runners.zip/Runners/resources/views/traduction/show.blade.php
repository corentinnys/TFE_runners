

<ul class="list-inline s-header__action s-header__action--lb">

  @foreach($langues as $langue)
        <li class="s-header__action-item"><a class="s-header__action-link " href= {!!action('LanguageController@choice', $langue->code)!!}>{{$langue->code}}</a></li>
  @endforeach
</ul>
