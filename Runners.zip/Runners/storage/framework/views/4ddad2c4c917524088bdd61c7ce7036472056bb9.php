<ul class="list-inline s-header__action s-header__action--rb">
    <?php echo $__env->make('Social.items', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</ul>
