
<!-- inclusion meta -->
<?php echo $__env->make('inc.head.meta', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- inclusion css -->
  <?php echo $__env->make('inc.head.css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
