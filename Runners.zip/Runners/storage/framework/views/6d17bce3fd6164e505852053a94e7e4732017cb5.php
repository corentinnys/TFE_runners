
<div class="s-swiper js__swiper-slider">
    <!-- Swiper Wrapper -->
    <div class="swiper-wrapper">
        <div class="s-promo-block-v4 g-fullheight--xs g-bg-position--center swiper-slide" style="background: url(<?php echo e(asset('img/1920x1080/14.jpg')); ?>);">
            <div class="container g-ver-center--xs">
                <div class="row">
                    <div class="col-md-7">
                        <div class="g-margin-b-50--xs">
                            <h1 class="g-font-size-32--xs g-font-size-45--sm g-font-size-60--md g-color--white">Medical Services<br>that You Can Trust</h1>
                            <p class="g-font-size-18--xs g-font-size-22--sm g-color--white-opacity">A clinic is a healthcare facility that is primarily focused on the care of outpatients.</p>
                        </div>
                        <a href="http://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes" class="text-uppercase s-btn s-btn--md s-btn--white-brd g-radius--50 g-padding-x-50--xs">Read More</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="s-promo-block-v4 g-fullheight--xs g-bg-position--center swiper-slide" style="background: url('img/1920x1080/13.jpg');">
            <div class="container g-text-right--xs g-ver-center--xs">
                <div class="row">
                    <div class="col-md-7 col-md-offset-5">
                        <div class="g-margin-b-50--xs">
                            <h2 class="g-font-size-32--xs g-font-size-45--sm g-font-size-55--md g-color--white">Medical Excellence<br>Every Day</h2>
                            <p class="g-font-size-18--xs g-font-size-22--sm g-color--white-opacity">Clinics can be privately operated or publicly managed and funded.</p>
                        </div>
                        <a href="http://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes" class="text-uppercase s-btn s-btn--md s-btn--white-brd g-radius--50 g-padding-x-50--xs">Read More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Swiper Wrapper -->

    <!-- Pagination -->
    <div class="s-swiper__pagination-v1 s-swiper__pagination-v1--bc s-swiper__pagination-v1--white js__swiper-pagination"></div>
</div>
<!--========== END SWIPER SLIDER ==========-->

<!--========== PAGE CONTENT ==========-->
<!-- Services -->
<div class="container g-padding-y-80--xs g-padding-y-125--sm">
    <div class="row g-margin-b-10--xs">
      <div class="col-md-10 g-margin-b-60--xs g-margin-b-0--lg">
          <!-- Masonry Grid -->
          <div class="row g-row-col--5 g-overflow--hidden js__masonry">
            <section class="g-margin-b-30--xs">
                <p class="text-uppercase g-font-size-14--xs g-font-weight--700 g-color--primary g-letter-spacing--2 g-margin-b-15--xs">Mon Dossier Administratif</p>
                <!--<h2 class="g-font-size-32--xs g-font-size-36--sm">Vous êtes bien selectionner pour le match</h2>-->
                <h2 class="g-font-size-32--xs g-font-size-36--sm text-danger">Ton Dossier adminisatratif n'est pas en ordre</h2>
                <button><a href="">voir plus</a></button>
            </section>
          </div>
          <!-- End Masonry Grid -->
      </div>
        <div class="col-md-10 g-margin-b-60--xs g-margin-b-0--lg">
            <!-- Masonry Grid -->
            <div class="row g-row-col--5 g-overflow--hidden js__masonry">
              <section class="g-margin-b-30--xs">
                  <p class="text-uppercase g-font-size-14--xs g-font-weight--700 g-color--primary g-letter-spacing--2 g-margin-b-15--xs">Prochain match</p>
                  <!--<h2 class="g-font-size-32--xs g-font-size-36--sm">Vous êtes bien selectionner pour le match</h2>-->
                  <h2 class="g-font-size-32--xs g-font-size-36--sm text-danger">Vous n'êtes pas selectionner pour le match</h2>
              </section>
            </div>
            <!-- End Masonry Grid -->
        </div>
    </div>
</div>
<!-- End Services -->

<!-- Process -->
<div class="g-bg-color--primary-ltr">
    <div class="container g-padding-y-80--xs g-padding-y-125--sm">
        <div class="g-text-center--xs g-margin-b-100--xs">
            <p class="text-uppercase g-font-size-14--xs g-font-weight--700 g-color--white-opacity g-letter-spacing--2 g-margin-b-25--xs">Process</p>
            <h2 class="g-font-size-32--xs g-font-size-36--sm g-color--white">How it Works</h2>
        </div>
        <ul class="list-inline row g-margin-b-100--xs">
            <!-- Process -->
            <li class="col-sm-3 col-xs-6 g-full-width--xs s-process-v1 g-margin-b-60--xs g-margin-b-0--md">
                <div class="center-block g-text-center--xs">
                    <div class="g-margin-b-30--xs">
                        <span class="g-display-inline-block--xs g-width-100--xs g-height-100--xs g-font-size-38--xs g-color--primary g-bg-color--white g-box-shadow__dark-lightest-v4 g-padding-x-20--xs g-padding-y-20--xs g-radius--circle">01</span>
                    </div>
                    <div class="g-padding-x-20--xs">
                        <h3 class="g-font-size-18--xs g-color--white">Make an Appointment</h3>
                        <p class="g-color--white-opacity">Clinics can be privately operated or publicly managed.</p>
                    </div>
                </div>
            </li>
            <!-- End Process -->

            <!-- Process -->
            <li class="col-sm-3 col-xs-6 g-full-width--xs s-process-v1 g-margin-b-60--xs g-margin-b-0--md">
                <div class="center-block g-text-center--xs">
                    <div class="g-margin-b-30--xs">
                        <span class="g-display-inline-block--xs g-width-100--xs g-height-100--xs g-font-size-38--xs g-color--primary g-bg-color--white g-box-shadow__dark-lightest-v4 g-padding-x-20--xs g-padding-y-20--xs g-radius--circle">02</span>
                    </div>
                    <div class="g-padding-x-20--xs">
                        <h3 class="g-font-size-18--xs g-color--white">Primary Diagnostics</h3>
                        <p class="g-color--white-opacity">Clinics can be privately operated or publicly managed.</p>
                    </div>
                </div>
            </li>
            <!-- End Process -->

            <!-- Process -->
            <li class="col-sm-3 col-xs-6 g-full-width--xs s-process-v1 g-margin-b-60--xs g-margin-b-0--sm">
                <div class="center-block g-text-center--xs">
                    <div class="g-margin-b-30--xs">
                        <span class="g-display-inline-block--xs g-width-100--xs g-height-100--xs g-font-size-38--xs g-color--primary g-bg-color--white g-box-shadow__dark-lightest-v4 g-padding-x-20--xs g-padding-y-20--xs g-radius--circle">03</span>
                    </div>
                    <div class="g-padding-x-20--xs">
                        <h3 class="g-font-size-18--xs g-color--white">Daily Course</h3>
                        <p class="g-color--white-opacity">Clinics can be privately operated or publicly managed.</p>
                    </div>
                </div>
            </li>
            <!-- End Process -->

            <!-- Process -->
            <li class="col-sm-3 col-xs-6 g-full-width--xs s-process-v1">
                <div class="center-block g-text-center--xs">
                    <div class="g-margin-b-30--xs">
                        <span class="g-display-inline-block--xs g-width-100--xs g-height-100--xs g-font-size-38--xs g-color--primary g-bg-color--white g-box-shadow__dark-lightest-v4 g-padding-x-20--xs g-padding-y-20--xs g-radius--circle">04</span>
                    </div>
                    <div class="g-padding-x-20--xs">
                        <h3 class="g-font-size-18--xs g-color--white">Be Healthy</h3>
                        <p class="g-color--white-opacity">Clinics can be privately operated or publicly managed.</p>
                    </div>
                </div>
            </li>
            <!-- End Process -->
        </ul>

        <div class="g-text-center--xs">
            <div class="wow fadeInUp" data-wow-duration=".3" data-wow-delay=".1s">
                <a href="#js__scroll-to-appointment" class="text-uppercase s-btn s-btn--md s-btn--white-bg g-radius--50">Make an Appointment</a>
            </div>
        </div>
    </div>
</div>
<!-- End Process -->

<!-- Features -->
<div class="g-hor-divider__solid--sky-light">
    <div class="container g-padding-y-80--xs g-padding-y-125--sm">
        <div class="row g-margin-b-60--xs g-margin-b-70--md">
            <div class="col-sm-4 g-margin-b-60--xs g-margin-b-0--md">
                <!-- Media -->
                <div class="clearfix">
                    <div class="g-media g-width-60--xs">
                        <div class="wow fadeInUp" data-wow-duration=".3" data-wow-delay=".1s">
                            <!-- SVG Icon -->
                            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewbox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
                                <g>
                                    <circle style="fill:#13b1cd;" cx="256" cy="256" r="256"/>
                                    <path data-async style="fill:#FFFFFF;" d="M320.696,178.33v-39.04H100.122v233.267h26.624c0-19.441,15.759-35.205,35.205-35.205
                                        s35.205,15.759,35.205,35.205h123.244c0-19.441,15.759-35.205,35.205-35.205c19.441,0,35.205,15.759,35.205,35.205h26.522v-83.261
                                        l-34.504-94.479L320.696,178.33z"/>
                                    <path data-async style="fill:#48AFCC;" d="M161.946,345.344c-15.027,0-27.208,12.18-27.208,27.208s12.18,27.208,27.208,27.208
                                        s27.208-12.18,27.208-27.208S176.973,345.344,161.946,345.344z M355.62,345.344c-15.027,0-27.208,12.18-27.208,27.208
                                        s12.18,27.208,27.208,27.208c15.027,0,27.208-12.18,27.208-27.208S370.647,345.344,355.62,345.344z"/>
                                    <circle style="fill:#FFFFFF;" cx="162.074" cy="372.531" r="12.38"/>
                                    <circle style="fill:#FFFFFF;" cx="355.738" cy="372.531" r="12.38"/>
                                    <polygon style="fill:#48AFCC;" points="319.621,189.322 319.621,280.504 400.911,280.504 375.644,202.506  "/>
                                    <polygon style="fill:#13b1cd;" points="371.681,201.574 360.264,280.504 325.842,280.504 343.383,194.913  "/>
                                    <rect x="100.122" y="305.48" style="fill:#FC611F;" width="317.204" height="16.686"/>
                                    <path data-async style="fill:#FC611F;" d="M204.908,170.767c-30.751,0-55.675,24.929-55.675,55.675c0,30.751,24.929,55.675,55.675,55.675
                                        c30.751,0,55.675-24.929,55.675-55.675C260.582,195.692,235.658,170.767,204.908,170.767z M236.411,238.377h-19.569v19.569h-23.869
                                        v-19.569h-19.569v-23.869h19.569v-19.569h23.869v19.569h19.569L236.411,238.377L236.411,238.377z"/>
                                    <path data-async style="fill:#E34E10;" d="M204.908,170.767l-1.101,0.056v24.12h13.036v19.569h19.569v23.869h-19.569v19.569h-13.036v24.12
                                        l1.101,0.056c30.751,0,55.675-24.929,55.675-55.675C260.582,195.692,235.658,170.767,204.908,170.767z"/>
                                    <polygon style="fill:#FC611F;" points="301.184,128.85 271.534,128.85 278.748,102.461 293.975,102.461    "/>
                                    <polygon style="fill:#E34E10;" points="286.362,128.85 301.184,128.85 293.975,102.461 286.362,102.461    "/>
                                    <rect x="267.366" y="128.87" style="fill:#71C6DE;" width="38.354" height="10.435"/>
                                    <rect x="286.531" y="128.87" style="fill:#48AFCC;" width="19.174" height="10.435"/>
                                </g>
                            </svg>
                            <!-- End SVG Icon -->
                        </div>
                    </div>
                    <div class="g-media__body g-padding-x-20--xs">
                        <h3 class="g-font-size-18--xs g-margin-b-10--xs">Selection match</h3>
                        <p class="g-margin-b-0--xs">Vous etes selectionner pour le match du 16/03/78 aux runners a 13h</p>
                    </div>
                </div>
                <!-- End Media -->
            </div>
            <div class="col-sm-4 g-margin-b-60--xs g-margin-b-0--md">
                <!-- Media -->
                <div class="clearfix">
                    <div class="g-media g-width-60--xs">
                        <div class="wow fadeInUp" data-wow-duration=".3" data-wow-delay=".2s">
                            <!-- SVG Icon -->
                            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewbox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
                                <g>
                                    <circle style="fill:#13b1cd;" cx="256" cy="256" r="256"/>
                                    <path style="fill:#FC611F;" d="M385.316,163.466c-35.712-35.712-93.609-35.712-129.316,0c-35.712-35.712-93.609-35.712-129.316,0
                                        c-35.712,35.712-35.712,93.609,0,129.316L256,422.103l129.316-129.316C421.028,257.075,421.028,199.178,385.316,163.466z"/>
                                    <path style="fill:#E34E10;" d="M364.385,163.466c-25.032-33.423-86.062-26.783-108.385,0l0,0v258.637l108.385-129.321
                                        C394.317,257.075,392.32,200.76,364.385,163.466z"/>
                                    <path style="fill:#F7BF00;" d="M345.779,289.372c6.006,0,10.875-16.497,10.875-36.844s-4.869-36.844-10.875-36.844l-0.22,0.036
                                        v-0.036H166.221c-6.006,0-10.875,16.497-10.875,36.844s4.869,36.844,10.875,36.844h179.338v-0.041L345.779,289.372z"/>
                                    <path style="fill:#FDF35A;" d="M345.779,284.268c6.006,0,10.875-16.497,10.875-36.844s-4.869-36.844-10.875-36.844l-0.22,0.036
                                        v-0.036H166.221c-6.006,0-10.875,16.497-10.875,36.844s4.869,36.844,10.875,36.844h179.338v-0.036L345.779,284.268z"/>
                                    <path style="fill:#F7BF00;" d="M328.837,227.528c0,3.61,2.929,6.538,6.538,6.538c3.61,0,6.538-2.929,6.538-6.538
                                        c0-3.61-2.929-6.538-6.538-6.538C331.761,220.989,328.837,223.913,328.837,227.528z M298.445,227.528
                                        c0,3.61,2.929,6.538,6.538,6.538c3.61,0,6.538-2.929,6.538-6.538c0-3.61-2.929-6.538-6.538-6.538
                                        C301.373,220.989,298.445,223.913,298.445,227.528z M298.445,247.537c0,3.61,2.929,6.538,6.538,6.538
                                        c3.61,0,6.538-2.929,6.538-6.538s-2.929-6.538-6.538-6.538C301.373,240.998,298.445,243.927,298.445,247.537z M298.445,266.767
                                        c0,3.61,2.929,6.538,6.538,6.538c3.61,0,6.538-2.929,6.538-6.538c0-3.61-2.929-6.538-6.538-6.538
                                        C301.373,260.224,298.445,263.153,298.445,266.767z M328.837,266.767c0,3.61,2.929,6.538,6.538,6.538
                                        c3.61,0,6.538-2.929,6.538-6.538c0-3.61-2.929-6.538-6.538-6.538C331.761,260.224,328.837,263.153,328.837,266.767z
                                         M328.837,247.537c0,3.61,2.929,6.538,6.538,6.538c3.61,0,6.538-2.929,6.538-6.538s-2.929-6.538-6.538-6.538
                                        C331.761,240.998,328.837,243.927,328.837,247.537z M285.164,247.537c0-15.273-3.384-27.653-7.557-27.653v55.306
                                        C281.779,275.19,285.164,262.81,285.164,247.537z M213.555,227.528c0-3.61-2.929-6.538-6.538-6.538
                                        c-3.61,0-6.538,2.929-6.538,6.538c0,3.61,2.929,6.538,6.538,6.538C210.627,234.066,213.555,231.137,213.555,227.528z
                                         M183.163,266.767c0-3.61-2.929-6.538-6.538-6.538c-3.61,0-6.538,2.929-6.538,6.538c0,3.61,2.929,6.538,6.538,6.538
                                        C180.234,273.306,183.163,270.377,183.163,266.767z M183.163,227.528c0-3.61-2.929-6.538-6.538-6.538
                                        c-3.61,0-6.538,2.929-6.538,6.538c0,3.61,2.929,6.538,6.538,6.538C180.234,234.066,183.163,231.137,183.163,227.528z
                                         M226.836,247.537c0,15.273,3.384,27.653,7.557,27.653v-55.301C230.221,219.889,226.836,232.269,226.836,247.537z M213.555,266.767
                                        c0-3.61-2.929-6.538-6.538-6.538c-3.61,0-6.538,2.929-6.538,6.538c0,3.61,2.929,6.538,6.538,6.538
                                        C210.627,273.306,213.555,270.377,213.555,266.767z M183.163,247.537c0-3.61-2.929-6.538-6.538-6.538
                                        c-3.61,0-6.538,2.929-6.538,6.538s2.929,6.538,6.538,6.538C180.234,254.075,183.163,251.151,183.163,247.537z M213.555,247.537
                                        c0-3.61-2.929-6.538-6.538-6.538c-3.61,0-6.538,2.929-6.538,6.538s2.929,6.538,6.538,6.538
                                        C210.627,254.08,213.555,251.151,213.555,247.537z"/>
                                </g>
                            </svg>
                            <!-- End SVG Icon -->
                        </div>
                    </div>
                    <div class="g-media__body g-padding-x-20--xs">
                        <h3 class="g-font-size-18--xs g-margin-b-10--xs">Cardiology</h3>
                        <p class="g-margin-b-0--xs">Clinics can be privately operated or publicly managed and funded.</p>
                    </div>
                </div>
                <!-- End Media -->
            </div>
            <div class="col-sm-4">
                <!-- Media -->
                <div class="clearfix">
                    <div class="g-media g-width-60--xs">
                        <div class="wow fadeInUp" data-wow-duration=".3" data-wow-delay=".3s">
                            <!-- SVG Icon -->
                            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewbox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
                                <g>
                                    <circle style="fill:#13b1cd;" cx="256" cy="256" r="256"/>
                                    <polygon style="fill:#3194B0;" points="284.493,152.55 173.292,127.206 116.05,378.353 227.246,403.697 338.708,429.102
                                        395.95,177.956  "/>
                                    <rect x="128.819" y="127.206" style="fill:#71C6DE;" width="228.367" height="257.587"/>
                                    <rect x="242.893" y="127.206" style="fill:#48AFCC;" width="114.319" height="257.587"/>
                                    <path style="fill:#FFFFFF;" d="M317.281,269.911c2.12,2.074,5.514,2.038,7.588-0.082c2.074-2.12,2.033-5.514-0.087-7.593
                                        c-13.056-12.78-34.411-29.399-71.864-31.944v-15.34c33.516,2.504,52.639,17.377,64.358,28.846c2.12,2.079,5.514,2.043,7.588-0.082
                                        c2.074-2.12,2.033-5.514-0.087-7.588c-13.056-12.78-34.412-29.404-71.864-31.949v-16.148c29.174,2.253,45.896,14.177,56.187,23.388
                                        c0.865,0.778,1.956,1.162,3.036,1.162c1.244,0,2.493-0.512,3.389-1.516c1.674-1.869,1.516-4.746-0.353-6.42
                                        c-11.402-10.209-29.957-23.434-62.259-25.733v-1.925h-19.277v1.869c-32.855,2.099-52.316,15.002-63.043,26.004
                                        c-1.751,1.797-1.715,4.68,0.082,6.431c1.802,1.756,4.68,1.715,6.431-0.082c9.528-9.769,26.895-21.212,56.53-23.24v16.154
                                        c-38.016,2.319-60.401,18.504-72.678,32.271c-1.971,2.212-1.782,5.606,0.43,7.578c1.024,0.911,2.304,1.362,3.574,1.362
                                        c1.475,0,2.944-0.609,4.004-1.792c10.839-12.145,30.684-26.399,64.676-28.652v15.345c-38.016,2.319-60.401,18.504-72.678,32.266
                                        c-1.971,2.212-1.782,5.606,0.43,7.578c1.024,0.911,2.304,1.362,3.574,1.362c1.475,0,2.944-0.609,4.004-1.792
                                        c10.839-12.15,30.679-26.399,64.676-28.646v15.345c-38.016,2.319-60.401,18.504-72.678,32.266c-1.971,2.212-1.782,5.606,0.43,7.578
                                        c1.024,0.911,2.304,1.362,3.574,1.362c1.475,0,2.944-0.609,4.004-1.792c10.839-12.15,30.679-26.399,64.676-28.646v15.749
                                        c-33.285,2.58-52.936,18.627-63.749,32.302c-1.731,2.191-1.357,5.366,0.829,7.096c0.927,0.732,2.033,1.091,3.128,1.091
                                        c1.495,0,2.97-0.66,3.973-1.92c9.441-11.94,26.609-25.917,55.823-28.426v35.139h0.02c0.113,5.228,4.367,9.436,9.62,9.436
                                        c5.253,0,9.508-4.209,9.62-9.436h0.015v-0.143l-0.005-0.067l-0.005-0.067v-34.79c28.739,2.79,45.281,17.347,55.475,28.605
                                        c1.874,2.063,5.079,2.222,7.137,0.353c2.063-1.874,2.222-5.069,0.353-7.137c-11.489-12.692-30.223-29.148-62.966-31.974v-15.754
                                        c33.51,2.504,52.639,17.377,64.358,28.846c2.12,2.068,5.514,2.033,7.588-0.082c2.074-2.12,2.033-5.514-0.087-7.593
                                        c-13.056-12.78-34.411-29.399-71.864-31.944v-15.34C286.428,243.569,305.562,258.442,317.281,269.911z"/>
                                </g>
                            </svg>
                            <!-- End SVG Icon -->
                        </div>
                    </div>
                    <div class="g-media__body g-padding-x-20--xs">
                        <h3 class="g-font-size-18--xs g-margin-b-10--xs">X-Ray</h3>
                        <p class="g-margin-b-0--xs">Clinics can be privately operated or publicly managed and funded.</p>
                    </div>
                </div>
                <!-- End Media -->
            </div>
        </div>

        <div class="row g-margin-b-60--xs g-margin-b-70--md">
            <div class="col-sm-4 g-margin-b-60--xs g-margin-b-0--md">
                <!-- Media -->
                <div class="clearfix">
                    <div class="g-media g-width-60--xs">
                        <div class="wow fadeInUp" data-wow-duration=".3" data-wow-delay=".4s">
                            <!-- SVG Icon -->
                            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewbox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
                                <g>
                                    <circle style="fill:#13b1cd;" cx="256" cy="256" r="256"/>
                                    <path style="fill:#FFFFFF;" d="M331.72,120.586c-34.422,0-40.878,33.777-75.72,33.777l0,0
                                        c-34.847,0-41.298-33.777-75.72-33.777c-42.153,0-59.965,43.095-59.965,85.248s35.743,195.052,77.896,195.052
                                        c17.828,0,21.924-97.807,57.795-97.807s39.967,97.807,57.795,97.807c42.153,0,77.896-152.899,77.896-195.052
                                        S373.873,120.586,331.72,120.586z"/>
                                    <g>
                                        <path style="fill:#FFFFFF;" d="M331.72,120.586c-34.422,0-40.878,33.777-75.72,33.777l0,0
                                            c-34.847,0-41.298-33.777-75.72-33.777c-42.153,0-59.965,43.095-59.965,85.248s35.743,195.052,77.896,195.052
                                            c17.828,0,21.924-97.807,57.795-97.807s39.967,97.807,57.795,97.807c42.153,0,77.896-152.899,77.896-195.052
                                            S373.873,120.586,331.72,120.586z"/>
                                    </g>
                                    <path style="fill:#B6F0FF;" d="M256,287.529c-53.56,0-99.558-46.316-120.141-81.966l-0.005,0.271
                                        c0,50.171,35.22,163.517,57.846,177.971c2.56-5.949,5.663-16.292,7.9-23.736C211.318,327.747,223.396,287.529,256,287.529
                                        s44.687,40.228,54.4,72.55c2.237,7.439,5.34,17.777,7.895,23.731C340.92,369.341,376.141,256,376.141,205.839l-0.005-0.271
                                        C355.558,241.213,309.56,287.529,256,287.529z"/>
                                    <path style="fill:#B6F0FF;" d="M208.015,149.412c-3.149-2.591-5.914-4.787-8.576-6.656c6.508,26.132,29.327,45.471,56.561,45.471
                                        s50.048-19.333,56.556-45.466c-2.657,1.869-5.422,4.065-8.571,6.656c-11.11,9.134-24.94,20.506-47.99,20.506
                                        S219.126,158.541,208.015,149.412z"/>
                                </g>
                            </svg>
                            <!-- End SVG Icon -->
                        </div>
                    </div>
                    <div class="g-media__body g-padding-x-20--xs">
                        <h3 class="g-font-size-18--xs g-margin-b-10--xs">Dental</h3>
                        <p class="g-margin-b-0--xs">Clinics can be privately operated or publicly managed and funded.</p>
                    </div>
                </div>
                <!-- End Media -->
            </div>
            <div class="col-sm-4 g-margin-b-60--xs g-margin-b-0--md">
                <!-- Media -->
                <div class="clearfix">
                    <div class="g-media g-width-60--xs">
                        <div class="wow fadeInUp" data-wow-duration=".3" data-wow-delay=".5s">
                            <!-- SVG Icon -->
                            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewbox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
                                <g>
                                    <circle style="fill:#13b1cd;" cx="256" cy="256" r="256"/>
                                        <rect x="178.387" y="353.207" transform="matrix(0.9214 0.3887 -0.3887 0.9214 158.5036 -60.8026)" style="fill:#48AFCC;" width="102.291" height="16.303"/>
                                    <path style="fill:#48AFCC;" d="M253.619,403.948c12.232-18.442,23.158-37.514,28.636-59.192c5.069-21.13,7.598-41.359,6.205-63.094
                                        c-1.526-23.818-8.294-49.828-26.179-66.586c-1.725-1.613,13.43-21.489,15.529-24.612c35.19,26.24,46.879,71.301,48.763,113.362
                                        c1.05,23.439-2.898,46.469-8.556,69.1c-4.925,19.702-14.433,37.847-24.233,55.47C280.397,420.244,267.008,412.099,253.619,403.948z
                                        "/>

                                        <rect x="193.251" y="117.646" transform="matrix(0.9214 0.3887 -0.3887 0.9214 89.3742 -77.0569)" style="fill:#48AFCC;" width="83.781" height="129.448"/>

                                        <rect x="215.041" y="101.343" transform="matrix(0.9214 0.3887 -0.3887 0.9214 64.5272 -94.0148)" style="fill:#FFFFFF;" width="99.183" height="22.273"/>

                                        <rect x="156.064" y="241.143" transform="matrix(0.9214 0.3887 -0.3887 0.9214 114.2286 -60.0989)" style="fill:#FFFFFF;" width="99.183" height="22.273"/>

                                        <rect x="246.557" y="80.832" transform="matrix(0.9214 0.3887 -0.3887 0.9214 57.2357 -98.9914)" style="fill:#48AFCC;" width="53.46" height="22.273"/>

                                        <rect x="247.944" y="60.277" transform="matrix(0.9214 0.3887 -0.3887 0.9214 49.9237 -103.9572)" style="fill:#FFFFFF;" width="67.919" height="22.273"/>

                                        <rect x="194.885" y="109.502" transform="matrix(0.9214 0.3887 -0.3887 0.9214 84.6905 -70.1914)" style="fill:#71C6DE;" width="41.893" height="129.448"/>

                                        <rect x="262.721" y="110.981" transform="matrix(-0.9214 -0.3887 0.3887 -0.9214 504.9631 346.3874)" style="fill:#B6F0FF;" width="49.594" height="22.273"/>

                                        <rect x="296.625" y="117.862" transform="matrix(-0.9214 -0.3887 0.3887 -0.9214 533.4998 365.923)" style="fill:#FFFFFF;" width="14.275" height="22.273"/>

                                        <rect x="203.732" y="250.76" transform="matrix(-0.9214 -0.3887 0.3887 -0.9214 337.2933 592.0258)" style="fill:#B6F0FF;" width="49.594" height="22.273"/>

                                        <rect x="237.854" y="257.656" transform="matrix(-0.9214 -0.3887 0.3887 -0.9214 366.0814 611.6412)" style="fill:#FFFFFF;" width="14.106" height="22.273"/>

                                        <rect x="247.617" y="75.621" transform="matrix(0.9214 0.3887 -0.3887 0.9214 54.2425 -94.618)" style="fill:#71C6DE;" width="26.727" height="22.273"/>

                                        <rect x="280.383" y="66.91" transform="matrix(-0.9214 -0.3887 0.3887 -0.9214 541.0102 265.5378)" style="fill:#B6F0FF;" width="33.962" height="22.273"/>

                                        <rect x="303.701" y="71.533" transform="matrix(-0.9214 -0.3887 0.3887 -0.9214 560.9146 278.8186)" style="fill:#FFFFFF;" width="9.922" height="22.271"/>
                                    <path style="fill:#48AFCC;" d="M235.151,276.782l-20.628-8.704l-3.098,27.351l21.34,2.417L235.151,276.782z M210.975,266.578
                                        l-19.789-8.351l-10.26,24.325l19.789,8.351L210.975,266.578z M154.102,264.653l16.62,13.604l17.434-21.304l-20.628-8.704
                                        L154.102,264.653z"/>
                                    <path style="fill:#71C6DE;" d="M201.339,262.513l-10.153-4.285l-10.26,24.325l10.153,4.285L201.339,262.513z M154.102,264.653
                                        l16.62,13.604l17.434-21.304l-20.628-8.704L154.102,264.653z"/>

                                        <rect x="105.372" y="306.593" transform="matrix(0.9214 0.3887 -0.3887 0.9214 137.4635 -43.6342)" style="fill:#E34E10;" width="142.412" height="22.693"/>

                                        <rect x="108.167" y="292.712" transform="matrix(0.9214 0.3887 -0.3887 0.9214 129.4884 -31.9734)" style="fill:#FC611F;" width="71.206" height="22.693"/>
                                    <polygon style="fill:#48AFCC;" points="218.394,114.324 287.626,165.755 298.911,139.018 221.716,106.45   "/>
                                    <polygon style="fill:#48AFCC;" points="302.254,92.083 252.948,71.434 250.373,77.537 295.967,106.982     "/>
                                    <path style="fill:#48AFCC;" d="M197.827,261.033l-6.641-2.801l-3.169,7.516l9.912,4.849l3.41-8.084L197.827,261.033z
                                         M167.526,248.248l-4.372,5.34l19.82,9.692l5.181-6.333L167.526,248.248z"/>
                                    <path style="fill:#3194B0;" d="M305.987,222.843c-7.066-12.38-16.241-23.48-28.18-32.379c-2.099,3.123-17.254,22.999-15.529,24.617
                                        c7.844,7.347,13.45,16.527,17.51,26.476C291.215,239.836,300.846,232.714,305.987,222.843z"/>
                                    <circle style="fill:#71C6DE;" cx="273.306" cy="203.448" r="29.225"/>
                                    <circle style="fill:#48AFCC;" cx="273.306" cy="203.448" r="15.841"/>
                                    <path style="fill:#3194B0;" d="M260.475,206.879c0-8.75,7.091-15.841,15.841-15.841c3.958,0,7.537,1.505,10.312,3.907
                                        c-2.816-4.398-7.716-7.332-13.327-7.332c-8.75,0-15.841,7.091-15.841,15.841c0,4.787,2.171,9.032,5.53,11.935
                                        C261.412,212.92,260.475,210.017,260.475,206.879z"/>
                                    <path style="fill:#71C6DE;" d="M386.396,446.182v-30.013c0-9.595-7.777-17.372-17.372-17.372H178.381
                                        c-9.595,0-17.372,7.777-17.372,17.372v30.013H386.396z"/>
                                    <path style="fill:#48AFCC;" d="M386.396,446.182V421.96c0-9.595-7.777-17.372-17.372-17.372H273.7v41.595H386.396z"/>
                                    <polygon style="fill:#3194B0;" points="237.783,356.07 231.342,370.985 179.261,349.01 185.574,334.044    "/>
                                </g>
                            </svg>
                            <!-- End SVG Icon -->
                        </div>
                    </div>
                    <div class="g-media__body g-padding-x-20--xs">
                        <h3 class="g-font-size-18--xs g-margin-b-10--xs">Laboratory</h3>
                        <p class="g-margin-b-0--xs">Clinics can be privately operated or publicly managed and funded.</p>
                    </div>
                </div>
                <!-- End Media -->
            </div>
            <div class="col-sm-4">
                <!-- Media -->
                <div class="clearfix">
                    <div class="g-media g-width-60--xs">
                        <div class="wow fadeInUp" data-wow-duration=".3" data-wow-delay=".6s">
                            <!-- SVG Icon -->
                            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewbox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
                                <g>
                                    <circle style="fill:#13b1cd;" cx="256" cy="256" r="256"/>
                                    <path style="fill:#FFFFFF;" d="M290.811,102.036h-1.833V68.475c0-18.534-15.027-33.562-33.562-33.562s-33.562,15.027-33.562,33.562
                                        v33.562h-0.66c-47.79,0-86.533,38.743-86.533,86.533v119.962c0,47.79,38.743,86.533,86.533,86.533h13.778v9.503
                                        c0,11.069,8.975,20.04,20.04,20.04c11.069,0,20.04-8.97,20.04-20.04v-9.503h15.759c47.79,0,86.533-38.743,86.533-86.533V188.57
                                        C377.344,140.774,338.601,102.036,290.811,102.036z M255.416,55.24c7.306,0,13.23,5.924,13.23,13.23
                                        c0,7.306-5.924,13.23-13.23,13.23s-13.23-5.924-13.23-13.23C242.186,61.164,248.11,55.24,255.416,55.24z"/>
                                    <path style="fill:#B6F0FF;" d="M286.623,102.036h-1.613V68.475c0-18.534-13.251-33.562-29.594-33.562v20.332
                                        c6.441,0,13.23,4.388,13.23,13.23c0,8.55-6.82,13.23-13.23,13.23v342.866c9.59-0.22,17.311-9.073,17.311-19.999v-9.503h13.896
                                        c42.138,0,76.298-38.743,76.298-86.533V188.57C362.921,140.774,328.76,102.036,286.623,102.036z"/>
                                    <path style="fill:#68C4DE;" d="M221.189,380.646c-39.762,0-72.11-32.348-72.11-72.11V188.564c0-39.762,32.348-72.11,72.11-72.11
                                        h69.622c39.762,0,72.11,32.348,72.11,72.11v119.967c0,39.762-32.348,72.11-72.11,72.11h-69.622V380.646z"/>
                                    <path style="fill:#FC611F;" d="M149.105,188.068l-0.026,0.502v119.962c0,39.762,32.348,72.11,72.11,72.11h69.622
                                        c39.762,0,72.11-32.348,72.11-72.11V188.564l-0.026-0.502H149.105V188.068z"/>
                                    <path style="fill:#E34E10;" d="M347.776,188.068h-92.365v192.579h30.418c34.171,0,61.967-32.348,61.967-72.11V188.564
                                        L347.776,188.068z"/>
                                    <path style="fill:#FFFFFF;" d="M177.275,310.129h28.196v-7.757h-28.196V310.129z M177.275,343.316h28.196v-7.757h-28.196V343.316z
                                         M177.275,276.941h28.196v-7.757h-28.196V276.941z M177.275,243.753h28.196v-7.757h-28.196V243.753z M177.275,202.808v7.757h28.196
                                        v-7.757H177.275z M191.37,218.757h-14.095v7.757h14.095V218.757z M191.37,318.321h-14.095v7.757h14.095V318.321z M191.37,285.133
                                        h-14.095v7.757h14.095V285.133z M191.37,251.945h-14.095v7.757h14.095V251.945z"/>
                                    <path style="fill:#FC611F;" d="M271.473,461.035c0,8.868-7.188,16.056-16.056,16.056c-8.868,0-16.056-7.188-16.056-16.056
                                        s16.056-30.464,16.056-30.464S271.473,452.168,271.473,461.035z"/>
                                    <path style="fill:#E34E10;" d="M255.416,430.566v46.52c6.825,0,12.355-7.188,12.355-16.056
                                    C267.771,452.168,255.416,430.566,255.416,430.566z"/>
                                </g>
                            </svg>
                            <!-- End SVG Icon -->
                        </div>
                    </div>
                    <div class="g-media__body g-padding-x-20--xs">
                        <h3 class="g-font-size-18--xs g-margin-b-10--xs">Donation</h3>
                        <p class="g-margin-b-0--xs">Clinics can be privately operated or publicly managed and funded.</p>
                    </div>
                </div>
                <!-- End Media -->
            </div>
        </div>

        <div class="row">
            <div class="col-sm-4 g-margin-b-60--xs g-margin-b-0--md">
                <!-- Media -->
                <div class="clearfix">
                    <div class="g-media g-width-60--xs">
                        <div class="wow fadeInUp" data-wow-duration=".3" data-wow-delay=".7s">
                            <!-- SVG Icon -->
                            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewbox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
                                <g>
                                    <circle style="fill:#13b1cd;" cx="256" cy="256" r="256"/>
                                    <path style="fill:#E34E10;" d="M321.265,431.263c-9.457,0-17.398-7.368-17.976-16.937c-5.207-85.74-32.87-115.569-62.162-147.144
                                        c-32.026-34.534-65.147-70.246-67.4-168.274c-0.23-9.958,7.66-18.212,17.608-18.437c9.917-0.415,18.217,7.654,18.442,17.608
                                        c1.935,84.357,27.822,112.266,57.789,144.584c30.807,33.219,65.725,70.871,71.716,169.482c0.604,9.938-6.963,18.483-16.906,19.082
                                        L321.265,431.263z"/>
                                    <path style="fill:#FFFFFF;" d="M346.604,118.707h-154.23c-2.985,0-5.407-2.422-5.407-5.407s2.422-5.407,5.407-5.407h154.235
                                        c2.985,0,5.407,2.422,5.407,5.407S349.588,118.707,346.604,118.707z"/>
                                    <path style="fill:#FFFFFF;" d="M346.604,146.176H195.195c-2.985,0-5.407-2.422-5.407-5.407c0-2.985,2.422-5.407,5.407-5.407
                                        h151.409c2.985,0,5.407,2.422,5.407,5.407C352.01,143.754,349.588,146.176,346.604,146.176z"/>
                                    <path style="fill:#FFFFFF;" d="M346.604,173.655H200.31c-2.985,0-5.407-2.422-5.407-5.407c0-2.985,2.422-5.407,5.407-5.407h146.294
                                        c2.985,0,5.407,2.422,5.407,5.407C352.01,171.233,349.588,173.655,346.604,173.655z"/>
                                    <path style="fill:#FFFFFF;" d="M313.8,352.471H171.412c-2.985,0-5.407-2.422-5.407-5.407s2.422-5.407,5.407-5.407H313.8
                                        c2.985,0,5.407,2.422,5.407,5.407S316.785,352.471,313.8,352.471z"/>
                                    <path style="fill:#FFFFFF;" d="M318.761,379.95H174.234c-2.985,0-5.407-2.422-5.407-5.407c0-2.985,2.422-5.407,5.407-5.407h144.527
                                        c2.985,0,5.407,2.422,5.407,5.407C324.168,377.528,321.746,379.95,318.761,379.95z"/>
                                    <path style="fill:#FFFFFF;" d="M321.382,407.419H179.348c-2.985,0-5.407-2.422-5.407-5.407s2.422-5.407,5.407-5.407h142.034
                                        c2.985,0,5.407,2.422,5.407,5.407S324.367,407.419,321.382,407.419z"/>
                                    <path style="fill:#FC611F;" d="M180.224,434.724c-7.977,0-15.227-5.417-17.224-13.507c-24.832-100.828,39.014-145.3,90.317-181.038
                                        c51.871-36.127,92.841-64.66,68.05-139.561c-3.077-9.308,1.966-19.343,11.274-22.431c9.308-3.092,19.348,1.966,22.431,11.274
                                        c33.106,100.05-27.761,142.438-81.464,179.85c-51.052,35.553-95.145,66.268-76.14,143.411c2.345,9.523-3.471,19.133-12.989,21.478
                                        C183.06,434.555,181.627,434.724,180.224,434.724z"/>
                                </g>
                            </svg>
                            <!-- End SVG Icon -->
                        </div>
                    </div>
                    <div class="g-media__body g-padding-x-20--xs">
                        <h3 class="g-font-size-18--xs g-margin-b-10--xs">DNA Test</h3>
                        <p class="g-margin-b-0--xs">Clinics can be privately operated or publicly managed and funded.</p>
                    </div>
                </div>
                <!-- End Media -->
            </div>
            <div class="col-sm-4 g-margin-b-60--xs g-margin-b-0--md">
                <!-- Media -->
                <div class="clearfix">
                    <div class="g-media g-width-60--xs">
                        <div class="wow fadeInUp" data-wow-duration=".3" data-wow-delay=".8s">
                            <!-- SVG Icon -->
                            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewbox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
                                <g>
                                    <circle style="fill:#13b1cd;" cx="256" cy="256" r="256"/>
                                    <path style="fill:#FFFFFF;" d="M411.351,198.134H100.649c0,79.119,34.386,147.656,84.603,181.432
                                        c-9.61,11.095-11.126,14.536-14.469,29.071h171.192c-3.343-14.536-4.859-17.976-14.469-29.071h-0.758
                                        C376.965,345.789,411.351,277.253,411.351,198.134z"/>
                                    <polygon style="fill:#FC611F;" points="303.764,270.884 271.473,270.884 271.473,238.587 241.285,238.587 241.285,270.884
                                        208.988,270.884 208.988,301.071 241.285,301.071 241.285,333.363 271.473,333.363 271.473,301.071 303.764,301.071     "/>
                                    <path style="fill:#B6F0FF;" d="M313.641,379.561c40.914-33.772,68.931-102.313,68.931-181.432H256v181.432v29.071h69.458
                                        c-2.703-14.536-3.927-17.976-11.689-29.071H313.641z"/>
                                    <polygon style="fill:#E34E10;" points="271.473,270.884 271.473,238.587 256,238.587 256,333.363 271.473,333.363 271.473,301.071
                                        303.764,301.071 303.764,270.884     "/>
                                    <polygon style="fill:#71C6DE;" points="160.481,198.134 220.124,198.134 174.31,103.368 134.246,115.594   "/>
                                    <polygon style="fill:#48AFCC;" points="190.3,198.134 160.481,198.134 134.246,115.594 154.404,109.445    "/>
                                </g>
                            </svg>
                            <!-- End SVG Icon -->
                        </div>
                    </div>
                    <div class="g-media__body g-padding-x-20--xs">
                        <h3 class="g-font-size-18--xs g-margin-b-10--xs">Pharmacy</h3>
                        <p class="g-margin-b-0--xs">Clinics can be privately operated or publicly managed and funded.</p>
                    </div>
                </div>
                <!-- End Media -->
            </div>
            <div class="col-sm-4">
                <!-- Media -->
                <div class="clearfix">
                    <div class="g-media g-width-60--xs">
                        <div class="wow fadeInUp" data-wow-duration=".3" data-wow-delay=".9s">
                            <!-- SVG Icon -->
                            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewbox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
                                <g>
                                    <circle style="fill:#13b1cd;" cx="256" cy="256" r="256"/>
                                    <path style="fill:#71C6DE;" d="M202.173,331.776l16.087-15.923l-16.005-16.005l-95.785,95.785
                                        c17.664,17.664,46.305,17.664,63.974,0l31.734-31.734C193.306,355.026,193.306,340.644,202.173,331.776z"/>
                                    <path style="fill:#FFFFFF;" d="M196.413,353.772l-33.915,33.915c-10.476,10.475-26.061,12.513-38.794,6.595
                                        c-7.009-3.256-9.508-6.38-9.508-6.38l-7.726,7.726c17.664,17.664,46.305,17.664,63.974,0l31.734-31.734
                                        C199.27,360.991,197.417,357.473,196.413,353.772z"/>
                                    <path style="fill:#FC611F;" d="M229.924,263.419l-27.668,27.668c-2.417,2.417-2.417,6.339,0,8.76l15.995,15.995
                                        c2.417,2.417,6.339,2.417,8.76,0l27.668-27.668L229.924,263.419z"/>
                                    <path style="fill:#71C6DE;" d="M410.01,132.833l-24.75-24.75c-4.516-4.516-11.837-4.516-16.353,0L229.924,247.066
                                        c-4.516,4.516-4.516,11.837,0,16.353l24.75,24.75c4.516,4.516,11.837,4.516,16.353,0L410.01,149.187
                                        C414.525,144.671,414.525,137.349,410.01,132.833z"/>
                                    <path style="fill:#48AFCC;" d="M406.461,129.285l-8.827-8.827L242.304,275.794l8.827,8.827c3.22,3.22,9.492,2.171,14.008-2.345
                                        l138.982-138.982C408.632,138.778,409.682,132.506,406.461,129.285z"/>
                                    <path style="fill:#E34E10;" d="M242.304,275.794l-32.046,32.046l7.997,7.997c2.417,2.417,6.339,2.417,8.76,0l27.668-27.668
                                        L242.304,275.794z"/>
                                    <path style="fill:#3194B0;" d="M325.079,171.116l21.222,21.222c2.191,2.191,5.75,2.191,7.946,0c2.191-2.191,2.191-5.75,0-7.946
                                        l-21.222-21.222c-2.191-2.191-5.75-2.191-7.946,0C322.883,165.361,322.888,168.919,325.079,171.116z M340.895,197.75
                                        l-21.222-21.222c-2.191-2.191-5.75-2.191-7.946,0c-2.196,2.191-2.191,5.75,0,7.946l21.222,21.222c2.191,2.191,5.75,2.191,7.946,0
                                        C343.086,203.5,343.086,199.946,340.895,197.75z M327.537,211.108l-21.222-21.222c-2.191-2.191-5.75-2.191-7.946,0
                                        c-2.196,2.191-2.191,5.75,0,7.946l21.222,21.222c2.191,2.191,5.75,2.191,7.946,0C329.733,216.858,329.733,213.299,327.537,211.108z
                                         M314.184,224.461l-21.222-21.222c-2.191-2.191-5.75-2.191-7.946,0c-2.191,2.191-2.191,5.75,0,7.946l21.222,21.222
                                        c2.191,2.191,5.75,2.191,7.946,0C316.375,230.216,316.375,226.657,314.184,224.461z"/>
                                </g>
                            </svg>
                            <!-- End SVG Icon -->
                        </div>
                    </div>
                    <div class="g-media__body g-padding-x-20--xs">
                        <h3 class="g-font-size-18--xs g-margin-b-10--xs">Surgery</h3>
                        <p class="g-margin-b-0--xs">Clinics can be privately operated or publicly managed and funded.</p>
                    </div>
                </div>
                <!-- End Media -->
            </div>
        </div>
    </div>
</div>
<!-- End Features -->

<div class="container g-text-center--xs g-padding-y-80--xs">
    <p class="text-uppercase g-font-size-14--xs g-font-weight--700 g-color--primary g-letter-spacing--2 g-margin-b-25--xs">30 years caring about you</p>
    <h2 class="g-font-size-32--xs g-font-size-36--sm">Professional Specialists</h2>
</div>
<!-- Team -->
<div class="row g-row-col--0">
    <div class="col-md-3 col-xs-6 g-full-width--xs">
        <div class="wow fadeInUp" data-wow-duration=".3" data-wow-delay=".1s">
            <!-- Team -->
            <div class="s-team-v1">
                <img class="img-responsive g-width-100-percent--xs" src="img/400x400/03.jpg" alt="Image">
                <div class="g-text-center--xs g-bg-color--white g-padding-x-30--xs g-padding-y-40--xs">
                    <h2 class="g-font-size-18--xs g-margin-b-5--xs">Jack Daniels</h2>
                    <span class="g-font-size-15--xs g-color--text"><i>Cardiology</i></span>
                </div>
            </div>
            <!-- End Team -->
        </div>
    </div>
    <div class="col-md-3 col-xs-6 g-full-width--xs">
        <div class="wow fadeInUp" data-wow-duration=".3" data-wow-delay=".2s">
            <!-- Team -->
            <div class="s-team-v1">
                <img class="img-responsive g-width-100-percent--xs" src="img/400x400/04.jpg" alt="Image">
                <div class="g-text-center--xs g-bg-color--white g-padding-x-30--xs g-padding-y-40--xs">
                    <h3 class="g-font-size-18--xs g-margin-b-5--xs">Anna Kusaikina</h3>
                    <span class="g-font-size-15--xs g-color--text"><i>Pulmonology</i></span>
                </div>
            </div>
            <!-- End Team -->
        </div>
    </div>
    <div class="col-md-3 col-xs-6 g-full-width--xs">
        <div class="wow fadeInUp" data-wow-duration=".3" data-wow-delay=".3s">
            <!-- Team -->
            <div class="s-team-v1">
                <img class="img-responsive g-width-100-percent--xs" src="img/400x400/05.jpg" alt="Image">
                <div class="g-text-center--xs g-bg-color--white g-padding-x-30--xs g-padding-y-40--xs">
                    <h4 class="g-font-size-18--xs g-margin-b-5--xs">Lucas Richardson</h4>
                    <span class="g-font-size-15--xs g-color--text"><i>Dental</i></span>
                </div>
            </div>
            <!-- End Team -->
        </div>
    </div>
    <div class="col-md-3 col-xs-6 g-full-width--xs">
        <div class="wow fadeInUp" data-wow-duration=".3" data-wow-delay=".4s">
            <!-- Team -->
            <div class="s-team-v1">
                <img class="img-responsive g-width-100-percent--xs" src="img/400x400/06.jpg" alt="Image">
                <div class="g-text-center--xs g-bg-color--white g-padding-x-30--xs g-padding-y-40--xs">
                    <h4 class="g-font-size-18--xs g-margin-b-5--xs">Kira Doe</h4>
                    <span class="g-font-size-15--xs g-color--text"><i>Gynecology</i></span>
                </div>
            </div>
            <!-- End Team -->
        </div>
    </div>
</div>
<!-- End Team -->

<!-- Parallax -->
<div class="s-promo-block-v5 g-bg-position--center js__parallax-window" style="background: url(img/1920x1080/13.jpg) 50% 0 no-repeat fixed;">
    <div class="container g-text-center--xs g-padding-y-80--xs g-padding-y-125--sm">
        <div class="g-margin-b-80--xs">
            <h2 class="g-font-size-40--xs g-font-size-50--sm g-font-size-60--md g-color--white">The Fastest Way To Recover</h2>
        </div>
        <a href="http://keenthemes.com/" class="text-uppercase s-btn s-btn--md s-btn--white-brd g-radius--50">Learn More</a>
    </div>
</div>
<!-- End Parallax -->

<!-- News -->
<div class="container-fluid g-padding-y-80--xs g-padding-y-125--sm">
    <div class="g-text-center--xs g-margin-b-80--xs">
        <p class="text-uppercase g-font-size-14--xs g-font-weight--700 g-color--primary g-letter-spacing--2 g-margin-b-25--xs">Therapy News</p>
        <p>A clinic is a healthcare facility that<br>is primarily focused on the care of outpatients.</p>
    </div>

    <!-- Swiper -->
    <div class="s-swiper js__swiper-news">
        <!-- Wrapper -->
        <div class="swiper-wrapper g-margin-b-60--xs">
            <article class="s-promo-block-v6 g-bg-position--center swiper-slide" style="background: url('img/400x500/07.jpg');">
                <div class="g-text-center--xs g-padding-x-15--xs g-padding-x-30--lg g-padding-y-50--xs g-margin-t-120--xs">
                    <div class="g-margin-b-25--xs">
                        <h3 class="g-font-size-16--xs g-color--white g-margin-b-5--xs">Medical Services</h3>
                        <p class="g-color--white">Clinics can be privately operated.</p>
                    </div>
                    <a href="http://keenthemes.com/" class="text-uppercase s-btn s-btn--xs s-btn--white-brd g-radius--50">Read More</a>
                </div>
            </article>
            <article class="s-promo-block-v6 g-bg-position--center swiper-slide" style="background: url('img/400x500/08.jpg');">
                <div class="g-text-center--xs g-padding-x-15--xs g-padding-x-30--lg g-padding-y-50--xs g-margin-t-120--xs">
                    <div class="g-margin-b-25--xs">
                        <h3 class="g-font-size-16--xs g-color--white g-margin-b-5--xs">Medical Services</h3>
                        <p class="g-color--white">Clinics can be privately operated.</p>
                    </div>
                    <a href="http://keenthemes.com/" class="text-uppercase s-btn s-btn--xs s-btn--white-brd g-radius--50">Read More</a>
                </div>
            </article>
            <article class="s-promo-block-v6 g-bg-position--center swiper-slide" style="background: url('img/400x500/09.jpg');">
                <div class="g-text-center--xs g-padding-x-15--xs g-padding-x-30--lg g-padding-y-50--xs g-margin-t-120--xs">
                    <div class="g-margin-b-25--xs">
                        <h3 class="g-font-size-16--xs g-color--white g-margin-b-5--xs">Medical Services</h3>
                        <p class="g-color--white">Clinics can be privately operated.</p>
                    </div>
                    <a href="http://keenthemes.com/" class="text-uppercase s-btn s-btn--xs s-btn--white-brd g-radius--50">Read More</a>
                </div>
            </article>
            <article class="s-promo-block-v6 g-bg-position--center swiper-slide" style="background: url('img/400x500/10.jpg');">
                <div class="g-text-center--xs g-padding-x-15--xs g-padding-x-30--lg g-padding-y-50--xs g-margin-t-120--xs">
                    <div class="g-margin-b-25--xs">
                        <h3 class="g-font-size-16--xs g-color--white g-margin-b-5--xs">Medical Services</h3>
                        <p class="g-color--white">Clinics can be privately operated.</p>
                    </div>
                    <a href="http://keenthemes.com/" class="text-uppercase s-btn s-btn--xs s-btn--white-brd g-radius--50">Read More</a>
                </div>
            </article>
            <article class="s-promo-block-v6 g-bg-position--center swiper-slide" style="background: url('img/400x500/11.jpg');">
                <div class="g-text-center--xs g-padding-x-15--xs g-padding-x-30--lg g-padding-y-50--xs g-margin-t-120--xs">
                    <div class="g-margin-b-25--xs">
                        <h3 class="g-font-size-16--xs g-color--white g-margin-b-5--xs">Medical Services</h3>
                        <p class="g-color--white">Clinics can be privately operated.</p>
                    </div>
                    <a href="http://keenthemes.com/" class="text-uppercase s-btn s-btn--xs s-btn--white-brd g-radius--50">Read More</a>
                </div>
            </article>
            <article class="s-promo-block-v6 g-bg-position--center swiper-slide" style="background: url('img/400x500/12.jpg');">
                <div class="g-text-center--xs g-padding-x-15--xs g-padding-x-30--lg g-padding-y-50--xs g-margin-t-120--xs">
                    <div class="g-margin-b-25--xs">
                        <h3 class="g-font-size-16--xs g-color--white g-margin-b-5--xs">Medical Services</h3>
                        <p class="g-color--white">Clinics can be privately operated.</p>
                    </div>
                    <a href="http://keenthemes.com/" class="text-uppercase s-btn s-btn--xs s-btn--white-brd g-radius--50">Read More</a>
                </div>
            </article>
            <article class="s-promo-block-v6 g-bg-position--center swiper-slide" style="background: url('img/400x500/13.jpg');">
                <div class="g-text-center--xs g-padding-x-15--xs g-padding-x-30--lg g-padding-y-50--xs g-margin-t-120--xs">
                    <div class="g-margin-b-25--xs">
                        <h3 class="g-font-size-16--xs g-color--white g-margin-b-5--xs">Medical Services</h3>
                        <p class="g-color--white">Clinics can be privately operated.</p>
                    </div>
                    <a href="http://keenthemes.com/" class="text-uppercase s-btn s-btn--xs s-btn--white-brd g-radius--50">Read More</a>
                </div>
            </article>
        </div>
        <!-- End Wrapper -->

        <!-- Pagination -->
        <div class="s-swiper__pagination-v1 s-swiper__pagination-v1--dark g-text-center--xs js__swiper-pagination"></div>
    </div>
    <!-- End Swiper -->
</div>
<!-- End News -->

<!-- Form -->
<div id="js__scroll-to-appointment" class="g-bg-color--sky-light g-padding-y-80--xs g-padding-y-125--sm">
    <div class="container g-bg-color--white g-box-shadow__dark-lightest-v3">
        <div class="row">
            <!-- Form -->
            <div class="col-md-8 js__form-eqaul-height-v1">
                <div class="g-padding-x-40--xs g-padding-y-50--xs">
                    <h2 class="g-font-size-24--xs g-color--primary g-margin-b-50--xs">Make an Appointment</h2>
                    <form>
                        <div class="row g-margin-b-30--xs g-margin-b-50--md">
                            <div class="col-sm-6 g-margin-b-30--xs g-margin-b-0--md">
                                <input type="text" class="form-control s-form-v4__input g-padding-l-0--xs" placeholder="* Full Name">
                            </div>
                            <div class="col-sm-6">
                                <input type="text" class="form-control s-form-v4__input g-padding-l-0--xs" placeholder="* Phone Number">
                            </div>
                        </div>
                        <div class="row g-margin-b-50--xs g-margin-b-50--md">
                            <div class="col-sm-4 g-margin-b-30--xs g-margin-b-0--md">
                                <input type="text" class="form-control s-form-v4__input g-padding-l-0--xs" placeholder="* Department">
                            </div>
                            <div class="col-sm-4 g-margin-b-30--xs g-margin-b-0--md">
                                <input type="text" class="form-control s-form-v4__input g-padding-l-0--xs" placeholder="* Doctor">
                            </div>
                            <div class="col-sm-4">
                                <input type="text" class="form-control s-form-v4__input g-padding-l-0--xs" placeholder="* DD/MM/YY">
                            </div>
                        </div>
                        <div class="g-margin-b-50--xs">
                            <textarea class="form-control s-form-v4__input g-padding-l-0--xs" rows="5" placeholder="* What ails you?"></textarea>
                        </div>
                        <div class="g-text-center--xs">
                            <button type="submit" class="text-uppercase s-btn s-btn--md s-btn--primary-bg g-radius--50 g-padding-x-70--xs g-margin-b-20--xs">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
            <!-- End Form -->

            <!-- Contacts -->
            <div class="col-md-4 g-bg-color--primary-ltr js__form-eqaul-height-v1">
                <div class="g-overflow--hidden g-padding-x-40--xs g-padding-y-50--xs">
                    <h2 class="g-font-size-24--xs g-color--white g-margin-b-50--xs">Contact Us</h2>
                    <ul class="list-unstyled g-margin-b-70--xs">
                        <li class="clearfix g-color--white g-margin-b-40--xs">
                            <div class="g-media g-width-40--xs g-margin-t-5--xs">
                                <i class="g-font-size-20--xs g-color--white-opacity-light ti-location-pin"></i>
                            </div>
                            <div class="g-media__body">
                                277 Bedford Avenue, <br> Brooklyn, NY 11211, New York
                            </div>
                        </li>
                        <li class="clearfix g-color--white g-margin-b-40--xs">
                            <div class="g-media g-width-40--xs g-margin-t-5--xs">
                                <i class="g-font-size-20--xs g-color--white-opacity-light ti-headphone-alt"></i>
                            </div>
                            <div class="g-media__body">
                                + (1) 001 389 3720
                            </div>
                        </li>
                        <li class="clearfix g-color--white g-margin-b-40--xs">
                            <div class="g-media g-width-40--xs g-margin-t-5--xs">
                                <i class="g-font-size-20--xs g-color--white-opacity-light ti-email"></i>
                            </div>
                            <div class="g-media__body">
                                support@keenthemes.com
                            </div>
                        </li>
                    </ul>
                    <ul class="list-inline g-ul-li-lr-15--xs">
                        <li><a href="#"><i class="g-font-size-20--xs g-color--white-opacity ti-facebook"></i></a></li>
                        <li><a href="#"><i class="g-font-size-20--xs g-color--white-opacity ti-twitter"></i></a></li>
                        <li><a href="#"><i class="g-font-size-20--xs g-color--white-opacity ti-instagram"></i></a></li>
                    </ul>
                    <i class="g-font-size-150--xs g-color--white-opacity-lightest ti-comments" style="position: absolute; bottom: -1.25rem; right: -1.25rem;"></i>
                </div>
            </div>
            <!-- End Contacts -->
        </div>
    </div>
</div>
