<div class="col-sm-2 g-margin-b-20--xs g-margin-b-0--md">
    <ul class="list-unstyled g-ul-li-tb-5--xs g-margin-b-0--xs">
      <?php echo $__env->make('Social.items', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </ul>
</div>
