<?php $user = app('App\Repositories\UserRepository'); ?>
<br>
<?php if(Request::is('home')): ?>

  <ul class="list-unstyled s-header__nav-menu">
    <?php if($user->verifComite(Session::get('mail'))== true): ?>
      <li>
        <a href="" style="color:white">resumer de la derniere reunion</a>

      </li>
    <?php endif; ?>
        <li >
            <a href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                         document.getElementById('logout-form').submit();" style='color:white'>
                Déconnection
            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo e(csrf_field()); ?>

            </form>
        </li>

  </ul>
<?php else: ?>
<ul class="list-unstyled s-header__nav-menu">

  <?php $__currentLoopData = $itemsMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($items->nom != "slug"): ?>
  <li class="s-header__nav-menu-item">

    <a class="s-header__nav-menu-link s-header__nav-menu-link-divider"

     href="<?php echo e(URL::to(App::getLocale()."/$items->valeur")); ?>">

      <?php echo e($items->valeur); ?>

     </a>

   </li>
<?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <li class="s-header__nav-menu-item">

    <a class="s-header__nav-menu-link s-header__nav-menu-link-divider"

     href="<?php echo e(URL::to('/login')); ?>">

      Mon espace
     </a>

   </li>
</ul>
<?php endif; ?>
