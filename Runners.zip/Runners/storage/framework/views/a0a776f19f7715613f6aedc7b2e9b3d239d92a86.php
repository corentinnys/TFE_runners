<footer class="g-bg-color--dark">
    <!-- Links -->
    <div class="g-hor-divider__dashed--white-opacity-lightest">
        <div class="container g-padding-y-80--xs">
            <div class="row">
                <div class="col-sm-2 g-margin-b-20--xs g-margin-b-0--md">
                    <ul class="list-unstyled g-ul-li-tb-5--xs g-margin-b-0--xs">
                        <li><a class="g-font-size-15--xs g-color--white-opacity" href="#">Home</a></li>
                        <li><a class="g-font-size-15--xs g-color--white-opacity" href="#">A propos</a></li>
                        <li><a class="g-font-size-15--xs g-color--white-opacity" href="#">Work</a></li>
                        <li><a class="g-font-size-15--xs g-color--white-opacity" href="#">Contact</a></li>
                    </ul>
                </div>
                <?php echo $__env->make('Social.social', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <div class="col-sm-2 g-margin-b-40--xs g-margin-b-0--md">
                    <ul class="list-unstyled g-ul-li-tb-5--xs g-margin-b-0--xs">
                        <li><a class="g-font-size-15--xs g-color--white-opacity" href="#newsletter">Inscrivez-vous à notre Newsletter</a></li>
                        <li><a class="g-font-size-15--xs g-color--white-opacity" href="#">Privacy Policy</a></li>
                        <li><a class="g-font-size-15--xs g-color--white-opacity" href="#">Terms &amp; Conditions</a></li>
                        <li><a class="g-font-size-15--xs g-color--white-opacity" href="#">Inscription</a></li>
                    </ul>
                </div>
                <div class="col-md-4 col-md-offset-2 col-sm-5 col-sm-offset-1 s-footer__logo g-padding-y-50--xs g-padding-y-0--md">
                    <h3 class="g-font-size-18--xs g-color--white">Megakit</h3>
                    <p class="g-color--white-opacity">We are a creative studio focusing on culture, luxury, editorial &amp; art. Somewhere between sophistication and simplicity.</p>
                </div>
            </div>
        </div>
    </div>
    <!-- End Links -->

    <!-- Copyright -->
    <?php echo $__env->make('footer.copyright', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- End Copyright -->
</footer>
