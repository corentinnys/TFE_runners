

<ul class="list-inline s-header__action s-header__action--lb">

  <?php $__currentLoopData = $langues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $langue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="s-header__action-item"><a class="s-header__action-link " href= <?php echo action('LanguageController@choice', $langue->code); ?>><?php echo e($langue->code); ?></a></li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
