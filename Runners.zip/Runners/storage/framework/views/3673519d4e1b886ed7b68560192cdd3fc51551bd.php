<!DOCTYPE html>
<html lang="en" class="no-js">
    <!-- Begin Head -->
    <head>
      <?php echo $__env->make('inc.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>
    <!-- End Head -->

    <!-- Body -->
    <body>

        <!--========== HEADER ==========-->
        <?php if(Request::is('login')): ?>
          <?php echo $__env->make('pages.connection', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php else: ?>
          <?php echo $__env->make('pages.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php endif; ?>
        <!--========== END HEADER ==========-->

        <!--========== SWIPER SLIDER ==========-->
        <?php if(Request::is(App::getLocale())): ?>

          <div class="s-swiper js__swiper-one-item">
              <!-- Swiper Wrapper -->
              <div class="swiper-wrapper">
                  <?php echo $__env->make('widgets.slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              </div>
              <!-- End Swiper Wrapper -->

              <!-- Arrows -->
              <a href="javascript:void(0);" class="s-swiper__arrow-v1--right s-icon s-icon--md s-icon--white-brd g-radius--circle ti-angle-right js__swiper-btn--next"></a>
              <a href="javascript:void(0);" class="s-swiper__arrow-v1--left s-icon s-icon--md s-icon--white-brd g-radius--circle ti-angle-left js__swiper-btn--prev"></a>
              <!-- End Arrows -->

              <a href="#js__scroll-to-section" class="s-scroll-to-section-v1--bc g-margin-b-15--xs">
                  <span class="g-font-size-18--xs g-color--white ti-angle-double-down"></span>
                  <p class="text-uppercase g-color--white g-letter-spacing--3 g-margin-b-0--xs">Learn More</p>
              </a>
          </div>
        <?php endif; ?>


        <!--========== END SWIPER SLIDER ==========-->

        <!--========== PAGE CONTENT ==========-->

        <?php echo $__env->yieldContent('content'); ?>

        <?php if(Request::is('FR/Contact')): ?>
          <?php echo $__env->make('pages.contact', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>

        <!-- Features -->
        <!--<div id="js__scroll-to-section" class="container g-padding-y-80--xs g-padding-y-125--sm">
            <div class="g-text-center--xs g-margin-b-100--xs">
                <p class="text-uppercase g-font-size-14--xs g-font-weight--700 g-color--primary g-letter-spacing--2 g-margin-b-25--xs">Welcome to Megakit</p>
                <h2 class="g-font-size-32--xs g-font-size-36--md">Notre club</h2>
            </div>
            <div class="row g-margin-b-60--xs g-margin-b-70--md">
                <div class="col-sm-4 g-margin-b-60--xs g-margin-b-0--md">
                    <div class="clearfix">
                        <div class="g-media g-width-30--xs">
                            <div class="wow fadeInDown" data-wow-duration=".3" data-wow-delay=".1s">
                                <i class="g-font-size-28--xs g-color--primary ti-desktop"></i>
                            </div>
                        </div>
                        <div class="g-media__body g-padding-x-20--xs">
                            <h3 class="g-font-size-18--xs">Notre vision</h3>
                            <p class="g-margin-b-0--xs">Le CRBB The Runners a pour objectifs de développer la pratique du basket ball dans une atmosphere familiale, aussi bien sur et autour du terrain, et selon le respect d'une certaine éthique sportive (respect de l'adversaire, entraide, complémentarité et équilibre entre le dépassement et le respect de soi). Le club s’efforce d'avoir des représentants de toutes les tranches d'âge (des jeunes jusqu’aux vétérans) et veut offrir á chaque membre la possibilité d'améliorer son niveau de manière responsable.</p>
                            <a href="#">read more </a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 g-margin-b-60--xs g-margin-b-0--md">
                    <div class="clearfix">
                        <div class="g-media g-width-30--xs">
                            <div class="wow fadeInDown" data-wow-duration=".3" data-wow-delay=".2s">
                                <i class="g-font-size-28--xs g-color--primary ti-settings"></i>
                            </div>
                        </div>
                        <div class="g-media__body g-padding-x-20--xs">
                            <h3 class="g-font-size-18--xs">Objectif  et finalité du club</h3>
                            <p class="g-margin-b-0--xs">
                              Promouvoir :
                              <ul>
                                <li>Le développement équilibré des facultés physiques, intellectuelles, artistiques , éthiques et sociales</li>
                                <li>la compréhension des valeurs morales et de l’esprit sportif</li>
                                <li>la discipline et les règles le respect de soi-même et d’autrui</li>
                                <li>l’apprentissage de la tolérance et de la responsabilité, éléments essentiels de la vie dans une société démocratique</li>
                                <li>l’acquisition de la maîtrise de soi, de l’accomplissement de soi</li>
                                <li>l'acquisition d’un mode de vie sain</li>
                              </ul>
                            </p>
                            <a href="#">read more </a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="clearfix">
                        <div class="g-media g-width-30--xs">
                            <div class="wow fadeInDown" data-wow-duration=".3" data-wow-delay=".3s">
                                <i class="g-font-size-28--xs g-color--primary ti-ruler-alt-2"></i>
                            </div>
                        </div>
                        <div class="g-media__body g-padding-x-20--xs">
                            <h3 class="g-font-size-18--xs">Lutter contre la violence</h3>
                            <p class="g-margin-b-0--xs">Notre club s’engage à combattre au sein de leurs équipes toutes les formes de haine, de violence, de segrégation ou de rejet qui gangrènent parfois les pratiques sportives les plus démocratiques et les plus respectables.</p>
                          <a href="#">read more </a>
                        </div>
                    </div>
                </div>
            </div>-->
            <!-- // end row  -->
            <!--<div class="row">
                <div class="col-sm-4 g-margin-b-60--xs g-margin-b-0--md">
                    <div class="clearfix">
                        <div class="g-media g-width-30--xs">
                            <div class="wow fadeInDown" data-wow-duration=".3" data-wow-delay=".4s">
                                <i class="g-font-size-28--xs g-color--primary ti-package"></i>
                            </div>
                        </div>
                        <div class="g-media__body g-padding-x-20--xs">
                            <h3 class="g-font-size-18--xs">les échanges internationnaux</h3>
                            <p class="g-margin-b-0--xs">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Placeat beatae explicabo possimus nulla unde qui aut recusandae hic, quis maiores deleniti illum soluta, aperiam, ipsum alias iste, quos id. Nemo optio, ducimus harum fugiat totam voluptatem, sit sunt voluptatum, recusandae voluptatibus reprehenderit repellendus nobis natus aut minus et eveniet! Temporibus.</p>
                            <a href="#">read more </a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 g-margin-b-60--xs g-margin-b-0--md">
                    <div class="clearfix">
                        <div class="g-media g-width-30--xs">
                            <div class="wow fadeInDown" data-wow-duration=".3" data-wow-delay=".5s">
                                <i class="g-font-size-28--xs g-color--primary ti-star"></i>
                            </div>
                        </div>
                        <div class="g-media__body g-padding-x-20--xs">
                            <h3 class="g-font-size-18--xs">Le sport pour tous</h3>
                            <p class="g-margin-b-0--xs">This is where we sit down, grab a cup of coffee and dial in the details.</p>
                          <a href="#">read more </a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="clearfix">
                        <div class="g-media g-width-30--xs">
                            <div class="wow fadeInDown" data-wow-duration=".3" data-wow-delay=".6s">
                                <i class="g-font-size-28--xs g-color--primary ti-panel"></i>
                            </div>
                        </div>
                        <div class="g-media__body g-padding-x-20--xs">
                            <h3 class="g-font-size-18--xs">Les droits et fonctions de chaque joueur/membre de CRBB The Runners</h3>
                            <p class="g-margin-b-0--xs">This is where we sit down, grab a cup of coffee and dial in the details.</p>
                            <a href="#">read more </a>
                        </div>
                    </div>
                </div>
            </div>-->
            <!-- // end row  -->
        <!--</div>-->

        <!-- End Features -->

        <!-- Parallax -->
          <?php if(Request::is('FR')): ?>
        <?php echo $__env->make('parallax', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- End Parallax -->

        <!-- Culture -->
        <div class="g-promo-section">
            <div class="container g-padding-y-80--xs g-padding-y-125--sm">
                <div class="row">
                    <div class="col-md-4 g-margin-t-15--xs g-margin-b-60--xs g-margin-b-0--lg">
                        <p class="text-uppercase g-font-size-14--xs g-font-weight--700 g-color--primary g-letter-spacing--2 g-margin-b-25--xs">Culture</p>
                        <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".1s">
                            <h2 class="g-font-size-40--xs g-font-size-50--sm g-font-size-60--md">Les runners</h2>
                        </div>
                        <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".3s">
                            <h2 class="g-font-size-40--xs g-font-size-50--sm g-font-size-60--md">Historique</h2>
                        </div>
                    </div>
                    <div class="col-md-4 col-md-offset-1">
                        <p class="g-font-size-18--xs">Le club des Runners a été créé en 1929. Il porte le matricule n°5 et est actuellement le plus vieux club de basket actif de Belgique (les numéros de 1 à 4 ayant stoppé leurs activités).
                   A cette époque, le cercle d’athlétisme de l’Union Saint-Gilloise était très important puisqu'il possédait en ses rangs des athlètes réputés sur le plan international (ex: Gaston Reiff).

Pratiquant un sport d’été, ces sportifs étaient à la recherche d’une activité complémentaire durant l'hiver. Le basket étant né depuis peu, le pas fut franchi. Ils créèrent une section basket sous le nom des Runners (« The Runners » en anglais voulant dire « les coureurs à pied » ) et restèrent dans la commune de Saint-Gilles, où le club évolue toujours.

En 1979, le club est devenu « Royal » et a fêté ses 75 ans en 2004.

L’actuel président n’est que le 5ème à occuper ce poste.</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-3 g-promo-section__img-right--lg g-bg-position--center g-height-100-percent--md js__fullwidth-img">
                <img class="img-responsive" src="img/970x970/03.jpg" alt="Image">
            </div>
        </div>
        <!-- End Culture -->

        <!-- Subscribe -->
        <div id="newsletter" class="js__parallax-window" style="background: url('img/1920x1080/07.jpg') 50% 0 no-repeat fixed;">
            <div class="g-container--sm g-text-center--xs g-padding-y-80--xs g-padding-y-125--sm">
                <div class="g-margin-b-80--xs">
                    <p class="text-uppercase g-font-size-14--xs g-font-weight--700 g-color--white-opacity g-letter-spacing--2 g-margin-b-25--xs"> notre newsletter</p>
                    <h2 class="g-font-size-32--xs g-font-size-36--md g-color--white">Suivez notre actualité</h2>
                </div>
                <div class="row">
                    <div class="col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1">
                        <form class="input-group" method="post" action='FR/newsletter' >
                            <input value="<?php echo e(old('email')); ?>" type="email" class=" s-form-v1__input g-radius--left-50" name="email" placeholder="Entrer votre mail">
                            <span class="input-group-btn">
                                <button type="submit"  class="s-btn s-btn-icon--md s-btn-icon--white-brd s-btn--white-brd g-radius--right-50"><i class="ti-arrow-right"></i></button>
                            </span>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Subscribe -->

        <!-- Portfolio Filter -->
        <div class="container g-padding-y-80--xs">
            <div class="g-text-center--xs g-margin-b-40--xs">
                <h2 class="g-font-size-32--xs g-font-size-36--md">Nos équipes</h2>
            </div>
            <div class="s-portfolio">
                <div id="js__filters-portfolio-gallery" class="s-portfolio__filter-v1 cbp-l-filters-text cbp-l-filters-center">
                    <div data-filter="*" class="s-portfolio__filter-v1-item cbp-filter-item cbp-filter-item-active">Toutes</div>
                    <div data-filter=".hommes" class="s-portfolio__filter-v1-item cbp-filter-item">Hommes</div>
                    <div data-filter=".seniors" class="s-portfolio__filter-v1-item cbp-filter-item">seniors</div>
                    <div data-filter=".jeunes" class="s-portfolio__filter-v1-item cbp-filter-item">jeunes</div>
                    <div data-filter=".femmes" class="s-portfolio__filter-v1-item cbp-filter-item">Femmes</div>
                </div>
            </div>
        </div>
        <!-- End Portfolio Filter -->

        <!-- Portfolio Gallery -->
        <div class="container g-margin-b-100--xs">
            <div id="js__grid-portfolio-gallery" class="cbp">
                <!-- Item -->
                <div class="s-portfolio__item cbp-item jeunes hommes">
                    <div class="s-portfolio__img-effect">
                        <img src="<?php echo e(asset('img/clients/u14.jpg')); ?>" alt="Equipes U14">
                    </div>
                    <div class="s-portfolio__caption-hover--cc">
                        <div class="g-margin-b-25--xs">
                            <h4 class="g-font-size-18--xs g-color--white g-margin-b-5--xs">U14</h4>
                            <p class="g-color--white-opacity">Lorem ipsum dolor sit amet</p>
                        </div>
                        <ul class="list-inline g-ul-li-lr-5--xs g-margin-b-0--xs">
                            <li>
                                <a href="<?php echo e(asset('img/970x647/05.jpg')); ?>" class="cbp-lightbox s-icon s-icon--sm s-icon--white-bg g-radius--circle" data-title="Portfolio Item <br/> by KeenThemes Inc.">
                                    <i class="ti-fullscreen"></i>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(URL::to('FR/equipes/u14')); ?>" class="s-icon s-icon--sm s-icon s-icon--white-bg g-radius--circle">
                                    <i class="ti-link"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Item -->
                <div class="s-portfolio__item cbp-item jeunes hommes">
                    <div class="s-portfolio__img-effect">
                        <img src="<?php echo e(asset('img/clients/u16.jpg')); ?>" alt="Portfolio Image">
                    </div>
                    <div class="s-portfolio__caption-hover--cc">
                        <div class="g-margin-b-25--xs">
                            <h4 class="g-font-size-18--xs g-color--white g-margin-b-5--xs">U14</h4>
                            <p class="g-color--white-opacity">Lorem ipsum dolor sit amet</p>
                        </div>
                        <ul class="list-inline g-ul-li-lr-5--xs g-margin-b-0--xs">
                            <li>
                                <a href="<?php echo e(asset('img/970x647/06.jpg')); ?>" class="cbp-lightbox s-icon s-icon--sm s-icon--white-bg g-radius--circle" data-title="Portfolio Item <br/> by KeenThemes Inc.">
                                    <i class="ti-fullscreen"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="s-icon s-icon--sm s-icon s-icon--white-bg g-radius--circle">
                                    <i class="ti-link"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Item -->
                <div class="s-portfolio__item cbp-item hommes jeunes">
                    <div class="s-portfolio__img-effect">
                        <img src="<?php echo e(asset('img/clients/u18.jpg')); ?>" style="height:300px;" alt="Portfolio Image">
                    </div>
                    <div class="s-portfolio__caption-hover--cc">
                        <div class="g-margin-b-25--xs">
                            <h4 class="g-font-size-18--xs g-color--white g-margin-b-5--xs">U18</h4>
                            <p class="g-color--white-opacity">Lorem ipsum dolor sit amet</p>
                        </div>
                        <ul class="list-inline g-ul-li-lr-5--xs g-margin-b-0--xs">
                            <li>
                                <a href="<?php echo e(asset('img/970x647/07.jpg')); ?>" class="cbp-lightbox s-icon s-icon--sm s-icon--white-bg g-radius--circle" data-title="Portfolio Item <br/> by KeenThemes Inc.">
                                    <i class="ti-fullscreen"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="s-icon s-icon--sm s-icon s-icon--white-bg g-radius--circle">
                                    <i class="ti-link"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Item -->
                <div class="s-portfolio__item cbp-item motion jeunes hommes">
                    <div class="s-portfolio__img-effect">
                        <img src="<?php echo e(asset('img/970x647/08.jpg')); ?>" alt="Portfolio Image">
                    </div>
                    <div class="s-portfolio__caption-hover--cc">
                        <div class="g-margin-b-25--xs">
                            <h4 class="g-font-size-18--xs g-color--white g-margin-b-5--xs">U21</h4>
                            <p class="g-color--white-opacity">Lorem ipsum dolor sit amet</p>
                        </div>
                        <ul class="list-inline g-ul-li-lr-5--xs g-margin-b-0--xs">
                            <li>
                                <a href="<?php echo e(asset('img/clients/u21.jpg')); ?>" class="cbp-lightbox s-icon s-icon--sm s-icon--white-bg g-radius--circle" data-title="Portfolio Item <br/> by KeenThemes Inc.">
                                    <i class="ti-fullscreen"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="s-icon s-icon--sm s-icon s-icon--white-bg g-radius--circle">
                                    <i class="ti-link"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Item -->
                <div class="s-portfolio__item cbp-item logos  hommes">
                    <div class="s-portfolio__img-effect">
                        <img src="<?php echo e(asset('img/970x647/09.jpg')); ?>" alt="Portfolio Image">
                    </div>
                    <div class="s-portfolio__caption-hover--cc">
                        <div class="g-margin-b-25--xs">
                            <h4 class="g-font-size-18--xs g-color--white g-margin-b-5--xs">Reserve</h4>
                            <p class="g-color--white-opacity">Lorem ipsum dolor sit amet</p>
                        </div>
                        <ul class="list-inline g-ul-li-lr-5--xs g-margin-b-0--xs">
                            <li>
                                <a href="<?php echo e(asset('img/clients/reserve.jpg')); ?>" class="cbp-lightbox s-icon s-icon--sm s-icon--white-bg g-radius--circle" data-title="Portfolio Item <br/> by KeenThemes Inc.">
                                    <i class="ti-fullscreen"></i>
                                </a>
                            </li>
                            <li>
                                <a href="https://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes" class="s-icon s-icon--sm s-icon s-icon--white-bg g-radius--circle">
                                    <i class="ti-link"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Item -->
                <div class="s-portfolio__item cbp-item  hommes seniors">
                    <div class="s-portfolio__img-effect">
                        <img src="img/970x647/04.jpg" alt="Portfolio Image">
                    </div>
                    <div class="s-portfolio__caption-hover--cc">
                        <div class="g-margin-b-25--xs">
                            <h4 class="g-font-size-18--xs g-color--white g-margin-b-5--xs"> P3 B</h4>
                            <p class="g-color--white-opacity">Lorem ipsum dolor sit amet</p>
                        </div>
                        <ul class="list-inline g-ul-li-lr-5--xs g-margin-b-0--xs">
                            <li>
                                <a href="<?php echo e(asset('img/970x647/04.jpg')); ?>" class="cbp-lightbox s-icon s-icon--sm s-icon--white-bg g-radius--circle" data-title="Portfolio Item <br/> by KeenThemes Inc.">
                                    <i class="ti-fullscreen"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="s-icon s-icon--sm s-icon s-icon--white-bg g-radius--circle">
                                    <i class="ti-link"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="s-portfolio__caption-hover--cc  hommes seniors">
                        <div class="g-margin-b-25--xs">
                            <h4 class="g-font-size-18--xs g-color--white g-margin-b-5--xs"> P3 A</h4>
                            <p class="g-color--white-opacity">Lorem ipsum dolor sit amet</p>
                        </div>
                        <ul class="list-inline g-ul-li-lr-5--xs g-margin-b-0--xs">
                            <li>
                                <a href="<?php echo e(asset('img/970x647/04.jpg')); ?>" class="cbp-lightbox s-icon s-icon--sm s-icon--white-bg g-radius--circle" data-title="Portfolio Item <br/> by KeenThemes Inc.">
                                    <i class="ti-fullscreen"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="s-icon s-icon--sm s-icon s-icon--white-bg g-radius--circle">
                                    <i class="ti-link"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="s-portfolio__caption-hover--cc  hommes seniors">
                        <div class="g-margin-b-25--xs">
                            <h4 class="g-font-size-18--xs g-color--white g-margin-b-5--xs">Vétéran</h4>
                            <p class="g-color--white-opacity">Lorem ipsum dolor sit amet</p>
                        </div>
                        <ul class="list-inline g-ul-li-lr-5--xs g-margin-b-0--xs">
                            <li>
                                <a href="<?php echo e(asset('img/970x647/04.jpg')); ?>" class="cbp-lightbox s-icon s-icon--sm s-icon--white-bg g-radius--circle" data-title="Portfolio Item <br/> by KeenThemes Inc.">
                                    <i class="ti-fullscreen"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="s-icon s-icon--sm s-icon s-icon--white-bg g-radius--circle">
                                    <i class="ti-link"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- End Item -->
            </div>
            <!-- End Portfolio Gallery -->
        </div>
        <!-- End Portfolio -->

        <!-- Testimonials -->

        <?php echo $__env->make('users.reaction', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php endif; ?>

        <!-- End Testimonials -->

        <!-- Clients -->

        <?php echo $__env->make('Pages.Sponsors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- End Clients -->

        <!-- News -->
        <?php if(Request::is('FR')): ?>
  <div class="container g-padding-y-80--xs g-padding-y-125--sm">
        <div class="g-text-center--xs g-margin-b-80--xs">
            <p class="text-uppercase g-font-size-14--xs g-font-weight--700 g-color--primary g-letter-spacing--2 g-margin-b-25--xs">Fans club des runners</p>
            <h2 class="g-font-size-32--xs g-font-size-36--md">Devenez un supporter des runners</h2>
        </div>
        <div class="container g-padding-y-80--xs g-padding-y-125--sm">
            <div class="row g-row-col--0 g-overflow--hidden">
                <div class="col-md-4 col-xs-6 g-full-width--xs">
                    <!-- Plan v2 -->
                    <div class="s-plan-v2 g-text-center--xs g-margin-t-0--xs g-margin-t-45--lg">
                        <div class="g-padding-x-30--xs g-padding-y-30--xs">
                            <h4 class="g-font-size-18--xs g-color--primary g-margin-b-5--xs">Nos pulls</h4>
                        </div>
                        <div>
                          <img src="<?php echo e(asset('img/clients/pull.png')); ?>">
                        </div>

                        <ul class="list-unstyled g-ul-li-tb-15--xs g-margin-b-0--xs">

                            <!--<li class="g-hor-divider__solid--sky-light">Couleur</li>-->
                            <li class="g-bg-color--sky-light">
                                <span class="g-font-size-18--xs g-font-weight--700 g-color--primary">Couleur</span>
                            </li>
                            <li>Jaune</li>
                            <li>Bleu</li>
                            <li class="g-bg-color--sky-light">
                                <span class="g-font-size-18--xs g-font-weight--700 g-color--primary">Tailles</span>
                            </li>
                            <li>S</li>
                            <li>M</li>
                            <li>L</li>
                            <li>X-L</li>
                            <li class="g-bg-color--sky-light">
                                <span class="g-font-size-18--xs g-font-weight--700 g-color--primary">$</span>
                                <span class="g-font-size-26--xs g-font-weight--700 g-color--primary">20.00</span>
                            </li>
                        </ul>
                        <div class="g-padding-x-40--xs g-padding-y-40--xs">
                            <button type="button" class="text-uppercase btn-block s-btn s-btn--sm s-btn--primary-brd g-radius--50">Achetez</button>
                        </div>
                    </div>
                    <!-- End Plan v2 -->

                </div>
                <div class="col-md-4 col-xs-push-2 col-xs-6 g-full-width--xs">
                    <!-- Plan v2 -->
                    <div class="s-plan-v2__main g-text-center--xs">
                        <div class="g-padding-x-30--xs g-padding-y-30--xs">
                            <i class="g-display-none--xs g-display-block--lg g-font-size-30--xs g-color--primary g-margin-b-20--xs "></i>
                            <!--<i class="g-display-none--xs g-display-block--lg g-font-size-30--xs g-color--primary g-margin-b-20--xs ti-crown"></i>-->
                            <h4 class="g-font-size-18--xs g-color--primary g-margin-b-5--xs">Nos t-shirts</h4>
                        </div>
                        <div>
                          <img src="<?php echo e(asset('img/clients/t-shirt.png')); ?>" style="width:100%">
                        </div>
                        <ul class="list-unstyled g-ul-li-tb-15--xs g-margin-b-0--xs">

                          <li class="g-bg-color--sky-light">
                              <span class="g-font-size-18--xs g-font-weight--700 g-color--primary">Couleur</span>
                          </li>
                          <li>Jaune</li>
                          <li>Bleu</li>
                          <li class="g-bg-color--sky-light">
                              <span class="g-font-size-18--xs g-font-weight--700 g-color--primary">Tailles</span>
                          </li>
                          <li>S</li>
                          <li>M</li>
                          <li>L</li>
                          <li>X-L</li>
                          <li class="g-bg-color--sky-light">
                              <span class="g-font-size-18--xs g-font-weight--700 g-color--primary">$</span>
                              <span class="g-font-size-26--xs g-font-weight--700 g-color--primary">20.00</span>
                          </li>
                        </ul>
                        <div class="g-padding-x-40--xs g-padding-y-40--xs">
                            <button type="button" class="text-uppercase btn-block s-btn s-btn--sm s-btn--primary-bg g-radius--50"><a href="#" style="color:white">Achetez</a></button>
                        </div>
                    </div>
                    <!-- End Plan v2 -->
                </div>
            </div>
        </div>
</div>



        <!-- Counter -->
        <div class="js__parallax-window" style="background: url(<?php echo e(asset('img/1920x1080/06.jpg')); ?>) 50% 0 no-repeat fixed;">
            <div class="container g-padding-y-80--xs g-padding-y-125--sm">
                <div class="row">
                    <div class="col-md-4 col-xs-6 g-full-width--xs g-margin-b-70--xs g-margin-b-0--lg">
                        <div class="g-text-center--xs">
                            <div class="g-margin-b-10--xs">
                                <figure class="g-display-inline-block--xs g-font-size-70--xs g-color--white js__counter">6</figure>
                                <span class="g-font-size-40--xs g-color--white"></span>
                            </div>
                            <div class="center-block g-hor-divider__solid--white g-width-40--xs g-margin-b-25--xs"></div>
                            <h4 class="g-font-size-18--xs g-color--white">Equipes</h4>
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-6 g-full-width--xs g-margin-b-70--xs g-margin-b-0--lg">
                        <div class="g-text-center--xs">
                            <figure class="g-display-block--xs g-font-size-70--xs g-color--white g-margin-b-10--xs js__counter">1</figure>
                            <div class="center-block g-hor-divider__solid--white g-width-40--xs g-margin-b-25--xs"></div>
                            <h4 class="g-font-size-18--xs g-color--white">Titre de champion</h4>
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-6 g-full-width--xs g-margin-b-70--xs g-margin-b-0--sm">
                        <div class="g-text-center--xs">
                            <figure class="g-display-block--xs g-font-size-70--xs g-color--white g-margin-b-10--xs js__counter">60</figure>
                            <div class="center-block g-hor-divider__solid--white g-width-40--xs g-margin-b-25--xs"></div>
                            <h4 class="g-font-size-18--xs g-color--white">Joueurs</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Counter -->

        <!-- Contact Form -->
          <?php echo $__env->make('formulaire.contact', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- End Contact Form -->

        <!-- Google Map -->
          <?php echo $__env->make('widgets.map', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- End Google Map -->
        <!--========== END PAGE CONTENT ==========-->
      <?php endif; ?>
        <!--========== FOOTER ==========-->
        <?php echo $__env->make('footer.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!--========== END FOOTER ==========-->

        <!-- Back To Top -->
        <a href="javascript:void(0);" class="s-back-to-top js__back-to-top"></a>

        <?php echo $__env->make('inc.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!--========== END JAVASCRIPTS ==========-->

    </body>
    <!-- End Body -->
</html>
