<div class="s-promo-block-v3 g-bg-position--center g-fullheight--sm" style="background: url(<?php echo e(asset('img/1920x1080/09.jpg')); ?>);">
    <div class="container g-ver-center--sm g-padding-y-125--xs g-padding-y-0--sm">
        <div class="g-margin-t-30--xs g-margin-t-0--sm g-margin-b-30--xs g-margin-b-70--md">
            <h1 class="g-font-size-35--xs g-font-size-45--sm g-font-size-50--lg g-color--white">Prochain <br>souper Runners<br></h1>
        </div>
        <div class="row">
            <div class="col-sm-8 col-sm-push-4 g-margin-b-50--xs g-margin-b-0--md">
                <div class="s-promo-block-v3__divider g-display-none--xs g-display-block--md"></div>
                <div class="row">
                    <div class="col-sm-6 g-margin-b-30--xs g-margin-b-0--md">
                        <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".4s">
                            <p class="g-font-size-18--xs g-color--white-opacity">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Modi, facere.</p>
                        </div>
                    </div>
                    <div class="col-sm-5 col-sm-offset-1">
                        <div class="clearfix">
                            <div class="pull-left">
                                <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".3s">
                                    <span class="s-promo-block-v3__date g-font-size-100--xs g-font-size-135--lg g-font-weight--300 g-color--primary">21</span>
                                </div>
                            </div>
                            <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".1s">
                                <span class="s-promo-block-v3__month g-font-size-18--xs g-font-size-22--lg g-font-weight--300 g-color--white-opacity-light">Dec</span>
                                <span class="s-promo-block-v3__year g-font-size-18--xs g-font-size-22--lg g-font-weight--300 g-color--white-opacity-light">2016</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-4 col-sm-pull-8">
                <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".5s">
                    <a class="js__popup__youtube" href="https://www.youtube.com/watch?v=lcFYdgZKZxY" title="Intro Video">
                        <i class="s-icon s-icon--lg s-icon--white-bg g-radius--circle ti-control-play"></i>
                        <span class="text-uppercase g-font-size-13--xs g-color--white g-padding-x-15--xs">l'ambiance aux runners</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Masonry -->

<!-- End Masonry -->

<!-- Features -->
<!--<div class="container g-padding-y-80--xs g-padding-y-125--sm">
    <div class="row g-margin-b-60--xs g-margin-b-70--md">
        <div class="col-sm-4 g-margin-b-60--xs g-margin-b-0--md">
            <div class="clearfix">
                <div class="g-media g-width-30--xs">
                    <div class="wow fadeInDown" data-wow-duration=".3" data-wow-delay=".1s">
                        <i class="g-font-size-28--xs g-color--primary ti-desktop"></i>
                    </div>
                </div>
                <div class="g-media__body g-padding-x-20--xs">
                    <h3 class="g-font-size-18--xs">Responsive Layout</h3>
                    <p class="g-margin-b-0--xs">This is where we sit down, grab a cup of coffee and dial in the details.</p>
                </div>
            </div>
        </div>
        <div class="col-sm-4 g-margin-b-60--xs g-margin-b-0--md">
            <div class="clearfix">
                <div class="g-media g-width-30--xs">
                    <div class="wow fadeInDown" data-wow-duration=".3" data-wow-delay=".2s">
                        <i class="g-font-size-28--xs g-color--primary ti-settings"></i>
                    </div>
                </div>
                <div class="g-media__body g-padding-x-20--xs">
                    <h3 class="g-font-size-18--xs">Fully Customizable</h3>
                    <p class="g-margin-b-0--xs">This is where we sit down, grab a cup of coffee and dial in the details.</p>
                </div>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="clearfix">
                <div class="g-media g-width-30--xs">
                    <div class="wow fadeInDown" data-wow-duration=".3" data-wow-delay=".3s">
                        <i class="g-font-size-28--xs g-color--primary ti-ruler-alt-2"></i>
                    </div>
                </div>
                <div class="g-media__body g-padding-x-20--xs">
                    <h3 class="g-font-size-18--xs">Pixel Perfect</h3>
                    <p class="g-margin-b-0--xs">This is where we sit down, grab a cup of coffee and dial in the details.</p>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-4 g-margin-b-60--xs g-margin-b-0--md">
            <div class="clearfix">
                <div class="g-media g-width-30--xs">
                    <div class="wow fadeInDown" data-wow-duration=".3" data-wow-delay=".4s">
                        <i class="g-font-size-28--xs g-color--primary ti-package"></i>
                    </div>
                </div>
                <div class="g-media__body g-padding-x-20--xs">
                    <h3 class="g-font-size-18--xs">Endless Possibilities</h3>
                    <p class="g-margin-b-0--xs">This is where we sit down, grab a cup of coffee and dial in the details.</p>
                </div>
            </div>
        </div>
        <div class="col-sm-4 g-margin-b-60--xs g-margin-b-0--md">
            <div class="clearfix">
                <div class="g-media g-width-30--xs">
                    <div class="wow fadeInDown" data-wow-duration=".3" data-wow-delay=".5s">
                        <i class="g-font-size-28--xs g-color--primary ti-star"></i>
                    </div>
                </div>
                <div class="g-media__body g-padding-x-20--xs">
                    <h3 class="g-font-size-18--xs">Powerful Performance</h3>
                    <p class="g-margin-b-0--xs">This is where we sit down, grab a cup of coffee and dial in the details.</p>
                </div>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="clearfix">
                <div class="g-media g-width-30--xs">
                    <div class="wow fadeInDown" data-wow-duration=".3" data-wow-delay=".6s">
                        <i class="g-font-size-28--xs g-color--primary ti-panel"></i>
                    </div>
                </div>
                <div class="g-media__body g-padding-x-20--xs">
                    <h3 class="g-font-size-18--xs">Parallax Support</h3>
                    <p class="g-margin-b-0--xs">This is where we sit down, grab a cup of coffee and dial in the details.</p>
                </div>
            </div>
        </div>
    </div>
</div>-->
<!-- End Features -->

<!-- Upcoming Event -->
<div class="s-promo-block-v2 js__parallax-window" style="background: url(<?php echo e(asset('img/1920x1080/03.jpg')); ?>) 50% 0 no-repeat fixed; background-size: cover;">
    <div class="container">
        <div class="row g-hor-centered-row--md">
            <div class="col-md-7 g-hor-centered-row__col g-padding-y-80--xs">
                <h2 class="g-font-size-40--xs g-font-size-50--sm g-font-size-60--md g-color--white">Notre futur souper</h2>
                <div class="g-margin-b-20--xs">
                    <span class="g-font-size-30--xs g-font-weight--700 g-color--white">4</span>
                    <span class="g-font-size-30--xs g-font-weight--700 g-color--white">Novembre</span>
                    <span class="g-font-size-30--xs g-color--white g-padding-x-5--xs"><i>2017</i></span>
                </div>
                <p class="g-font-size-18--xs g-color--white-opacity g-margin-b-40--xs">
                  Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                </p>
                <p class="text-uppercase s-btn s-btn--md s-btn--white-brd g-radius--50 g-padding-x-50--xs g-margin-b-20--xs">read more</p>
            </div>

            <div class="col-md-5 g-hor-centered-row__col g-margin-b-80--xs">
              <!--<div class="g-text-center--xs g-margin-b-40--xs">
                  <h2 class="g-font-size-30--xs g-color--white">Rejoindre l'événement</h2>
              </div>-->

                <form method="post" action="Evenements/contact">
                  <fieldset>
                    <legend style="color:white">information personnel</legend>

                    <div class="g-margin-b-40--xs">
                        <input type="text" name="nameReservation" placeholder="* le nom de la reservation" >
                    </div>
                    <div class="g-margin-b-40--xs">
                        <input type="email" name="email"  placeholder="* Email" >
                    </div>
                    <div class="g-margin-b-40--xs">
                        <input type="text" name="phone"  placeholder="* Phone">
                    </div>
                  </fieldset>
                    <fieldset>
                      <legend style="color:white">Nombre de reservation</legend>
                    <div class="g-margin-b-40--xs">
                        <input type="number" name="numberReservation"  placeholder="  pour le repas 1">
                    </div>
                    <div class="g-margin-b-40--xs">
                        <input type="number" name="numberReservation"  placeholder="   pour le repas 2">
                    </div>
                  </fieldset>

                    <div class="g-text-center--xs">
                        <button type="submit" class="text-uppercase btn-block s-btn s-btn--md s-btn--white-bg g-radius--50 g-padding-x-50--xs g-margin-b-20--xs">Join Now</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- End Upcoming Event -->

<?php echo $__env->make('parallax', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Plan -->

<!-- End Plan -->

<!-- Promo Section -->
<div class="g-promo-section">
    <div class="container g-padding-y-80--xs g-padding-y-125--sm">
        <div class="row">
            <div class="col-sm-5 col-sm-push-7">
                <div class="g-margin-b-30--xs">
                    <h3 class="g-font-size-32--xs g-font-size-36--sm"><a href="https://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes"> Evenements du mois de Décembre</a></h3>
                    <p>It’s important to stay detail oriented with every project we tackle. Staying focused allows us to turn every project we complete into something we love.</p>
                </div>
                <a href="http://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes" class="text-uppercase s-btn s-btn--sm s-btn--primary-brd g-radius--50 g-padding-x-40--xs">Read More</a>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-sm-pull-6 g-promo-section__img-right--md g-promo-section__img-left--md g-bg-position--center g-height-400--xs g-height-100-percent--md js__fullwidth-img">
        <img class="img-responsive" src="<?php echo e(asset('img/970x970/01.jpg')); ?>" alt="Image">
    </div>
</div>
<!-- End Promo Section -->

<!-- Promo Section -->
<div class="g-promo-section">
    <div class="container g-padding-y-80--xs g-padding-y-125--sm">
        <div class="row">
            <div class="col-sm-5">
                <div class="g-margin-b-30--xs">
                    <h3 class="g-font-size-32--xs g-font-size-36--sm"><a href="https://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes"> Evénement du mois de Janvier</a></h3>
                    <p>It’s important to stay detail oriented with every project we tackle. Staying focused allows us to turn every project we complete into something we love.</p>
                </div>
                <a href="http://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes" class="text-uppercase s-btn s-btn--sm s-btn--primary-brd g-radius--50 g-padding-x-40--xs">Read More</a>
            </div>
        </div>
    </div>
    <div class="col-sm-6 g-promo-section__img-right--md g-bg-position--center g-height-400--xs g-height-100-percent--md js__fullwidth-img">
        <img class="img-responsive" src="<?php echo e(asset('img/970x970/02.jpg')); ?>" alt="Image">
    </div>
</div>
<!-- End Promo Section -->

<!-- Clients -->
