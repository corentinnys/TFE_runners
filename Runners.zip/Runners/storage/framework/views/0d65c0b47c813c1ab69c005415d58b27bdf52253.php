<!-- Web Fonts -->
<link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i|Montserrat:400,700" rel="stylesheet">
<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">

<!-- Vendor Styles -->
<link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('css/animate.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('vendor/themify/themify.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('vendor/scrollbar/scrollbar.min.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('vendor/magnific-popup/magnific-popup.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('vendor/swiper/swiper.min.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('vendor/cubeportfolio/css/cubeportfolio.min.css')); ?>" rel="stylesheet" type="text/css"/>

<!-- Theme Styles -->
<link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('css/global/global.css')); ?>" rel="stylesheet" type="text/css"/>
<!-- Favicon -->
<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
<link rel="apple-touch-icon" href="img/apple-touch-icon.png">
