<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('Template.Base');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('FR/newsletter','newsletterController@new');

Route::get('/home', 'HomeController@index')->name('home');
Route::prefix('FR/equipes')->group(function () {
  Route::get('{equipes}','EquipesController@show');
});

route::get('FR/Inscription/telechargement/certificat','InscriptionController@telechargement');
Route::get('FR/Inscription/{param}','InscriptionController@page');
Route::prefix('FR/contact/')->group(function () {
  Route::get('club','ContactController@store');
});

Route::get('{langue}','LanguageController@choice');

Route::prefix('FR')->group(function () {
  Route::get('/profils/{username}','UserController@show');

});

Route::get('{langue}','LanguageController@choice');
Route::prefix('FR')->group(function () {
  Route::get('/','PageController@index');
  Route::get('/{title}','PageController@details');
});
