<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App;
use DB;

class PageController extends Controller
{
    public function index()
    {
      return view('Template.Base');
    }

    public function details($title = 'Acceuil')
    {
        if($title = 'MonEspace')
        {
           //return redirect('login');
        }
        $page = DB::table('traduction')
                    ->join('items', 'items.id', '=', 'traduction.item_id')
                    ->join('types', 'types.id', '=', 'items.type_id')
                    ->where('types.nom','=',$title)
                    //->where('item_id','=',7)
                    ->first();
            return view('pages.details',compact('page'));




    }


}
