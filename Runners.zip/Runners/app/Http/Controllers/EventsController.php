<?php

namespace App\Http\Controllers;

use App\Http\Requests\EventsRequest as EventsRequest;
use Illuminate\Support\Facades\Mail;
use App\Mail\Events;

class EventsController extends Controller
{
  private $_mail = 'administrateur@chezmoi.com';

  public function store(EventsRequest $request)
  {

      /*Mail::to($this->_mail)
          ->send(new Events($request->except('_token')));
        return view('events.confirm');*/
  }

  public function contact()
  {
    dd('test');
  }

}
