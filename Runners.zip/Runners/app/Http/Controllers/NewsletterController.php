<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Repositories\newsletterRepository;

class NewsletterController extends Controller
{

  private $_mail;

  public function new(Request $request, newsletterRepository $newsletterRepository)
  {
    $this->_mail = $request->input('email');
    $newsletterRepository->save($this->_mail);
    $lastMail = $newsletterRepository->lastMail();
    return view('newsletter.confirm',compact('lastMail'));
  }
}
