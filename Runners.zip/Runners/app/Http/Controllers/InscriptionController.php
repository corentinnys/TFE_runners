<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\InscriptionRequest as InscriptionRequest;
use App\Repositories\inscriptionRepository;
use Illuminate\Support\Facades\Mail;
use App\Mail\inscription ;


class InscriptionController extends Controller
{

    private $_mail = 'administrateur@chezmoi.com';


    public function page(InscriptionRequest $InscriptionRequest,inscriptionRepository $inscriptionRepository,$param)
    {
      if($param == 'payement')
      {
      /*  $inscriptionRepository->save($InscriptionRequest);*/
        $numberPage = 2;
      }
      else
      {
        $numberPage = 3 ;
        $this->sendMail($InscriptionRequest);
      }
        return view('pages.details',compact('numberPage'));
    }
    /**
 	 * Méthode qui permet de telecharger le certificat medical
 	 *
 	 * @return void
	 */

   public function sendMail($request)
   {

     Mail::to($this->_mail)
         ->send(new Inscription($request->except('_token')));
        /*  ->attach(storage_path('img/clients/certificat.pdf'));*/
        /*->attach('img/clients/certificat.pdf');*/

       return view('emails.inscription');

   }

    public function telechargement()
    {
      return response()->download('img/clients/certificat.pdf');
    }
}
