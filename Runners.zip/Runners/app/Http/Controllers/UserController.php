<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Repositories\UserRepository as UserRepository;

class UserController extends Controller
{
    public function show(UserRepository $UserRepository ,$username)
    {
      $user =$UserRepository->findOneByUserName($username);
    /*  $user = DB::table('users')
                  ->where('name','=',$username)
                  ->first();*/
      dd($user);
      return view('pages.details',compact('page'));
    }

  
}
