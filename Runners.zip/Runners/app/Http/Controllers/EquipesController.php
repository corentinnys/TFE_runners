<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class EquipesController extends Controller
{
    public function show($equipes)
    {

      $equipe = DB::table('traduction')
                  ->join('items', 'items.id', '=', 'traduction.item_id')
                  ->join('types', 'types.id', '=', 'items.type_id')
                  ->where('types.nom','=',$equipes)
                  ->orderBy('traduction.id', 'desc')
                  ->get();            
    return view('pages.details',compact('equipe'));
    }
}
