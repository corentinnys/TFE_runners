<?php

namespace App\Http\Controllers;
use App;
use Illuminate\Http\Request;

class LanguageController extends Controller
{

  public function choice($langues)
  {
      $local =App::setLocale($langues);
      return app()->make(PageController::class)->callAction('index', []);
  }
}
