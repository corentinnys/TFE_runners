<?php

namespace App\Http\Controllers;

use App\Http\Requests\ContactRequest as ContactRequest;
use Illuminate\Support\Facades\Mail;
use App\Mail\Contact;

class ContactController extends Controller
{
    private $_mail = 'administrateur@chezmoi.com';

    public function store(ContactRequest $request)
    {
        Mail::to($this->_mail)
            ->send(new Contact($request->except('_token')));
    return view('emails.confirm');
    }
}
