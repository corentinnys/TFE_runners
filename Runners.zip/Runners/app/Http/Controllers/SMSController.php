<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Illuminate\Notifications\Messages\NexmoMessage;
use Nexmo\Laravel\Facade\Nexmo;

class SMSController extends Controller
{

  
}
