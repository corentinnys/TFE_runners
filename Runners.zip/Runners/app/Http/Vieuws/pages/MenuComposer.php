<?php

namespace App\Http\Vieuws\pages;
use App;
use Illuminate\View\View;

use DB;

/**
 *
 */
class MenuComposer
{

    public function compose(View $view)
    {
      $itemsMenu = DB::table('langues')
                      ->join('traduction', 'langues.id', '=', 'traduction.langue_id')
                      ->join('champs', 'champs.id', '=', 'traduction.champ_id')
                      ->join('items', 'items.id', '=', 'traduction.item_id')
                      ->where('code','=', App::getLocale())
                      ->where('traduction.item_id','=',1)
                      ->get();
      $view->with(compact('itemsMenu'));
    }
}
