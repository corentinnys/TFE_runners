<?php

namespace App\Http\Vieuws\langues;

use Illuminate\View\View ;
use DB;

/**
 *
 */
class languesComposer 
{

    public function compose(View $view)
    {
      $langues = DB::table('langues')->get();
      $view->with(compact('langues'));
    }
}
