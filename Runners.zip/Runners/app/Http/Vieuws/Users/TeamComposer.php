<?php

namespace App\Http\Vieuws\Users;
use App;
use Illuminate\View\View;

use Request;
use DB;
use App\Repositories\UserRepository;
/**
 *
 */
class TeamComposer

{

    private $_table ='users';
    private $_repository ;

  /*  public function __construct(UserRepository $user)
    {
      $this->repository = $user;
    }*/

    public function compose(View $view)
    {
      if(Request::is('FR/Comite'))
      {
        $users= DB::table($this->_table)
                ->where('isComite', '=',1)
                ->get();
      //  $users = $this->repository->verifComite(1);
      }else{
        $users = DB::table($this->_table)
                ->get();
      //  $users = $this->repository->verifComite(0);
      }

      $view->with(compact('users'));
    }
}
