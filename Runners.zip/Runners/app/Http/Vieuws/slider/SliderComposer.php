<?php

namespace App\Http\Vieuws\slider;
use App;
use Illuminate\View\View;


use DB;

/**
 *
 */
class SliderComposer

{
    private $_table ='traduction';
    public function compose(View $view)
    {
      $itemsSlider = DB::table($this->_table)
                  ->join('items', 'items.id', '=', 'traduction.item_id')
                  ->join('types', 'types.id', '=', 'items.type_id')
                  ->where('types.nom','=','slider')
                  ->get();
      $view->with(compact('itemsSlider'));
    }
}
