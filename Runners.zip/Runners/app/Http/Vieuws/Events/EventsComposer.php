<?php

namespace App\Http\Vieuws\Events;

use Illuminate\View\View ;
use DB;

/**
 *
 */
class EventsComposer
{


}
