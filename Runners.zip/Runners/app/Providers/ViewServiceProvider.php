<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\view ;
use App\Http\Vieuws\langues\languesComposer as languesComposer;
use App\Http\Vieuws\pages\MenuComposer as MenuComposer;
use App\Http\Vieuws\slider\SliderComposer as SliderComposer;
use App\Http\Vieuws\Users\TeamComposer ;


class ViewServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap the application services.
     *
     * @return void
     */
    public function boot()
    {
        //View::composer('pages.menu',MenuComposer::class);
        //View::composer('traduction.show',languesComposer::class);
        //View::composer('widgets.slider',SliderComposer::class);
    }

    /**
     * Register the application services.
     *
     * @return void
     */
    public function register()
    {
      View::composer('pages.menu',MenuComposer::class);
      View::composer('traduction.show',languesComposer::class);
      View::composer('widgets.slider',SliderComposer::class);
      View::composer('users.all',TeamComposer::class);

    }
}
