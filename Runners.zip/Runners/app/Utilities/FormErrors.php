<?php

 namespace App\Utilities;

 /**
  *
  */
 class FormErrors
 {
   private $_couleur = "red";
   private $_tag = "div";

   public function formatting($message)
   {
     $messageFormater =$this->SetMessageFormat($message);

     return $messageFormater;
   }

   private function SetMessageFormat($message)
   {
     return "<$this->_tag "." ".$this->GetMessageColor().">$message</$this->_tag>";
   }

   private function GetMessageColor()
   {

     return "style=color:$this->_couleur";
   }

 }
