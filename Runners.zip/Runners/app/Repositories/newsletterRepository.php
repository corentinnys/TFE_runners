<?php
namespace App\Repositories;
use DB;


/**
 *
 */
class newsletterRepository extends repository
{
  private $_table = "newsletter";



  public function save($mail)
  {
    DB::table($this->_table)->insert(
      ['email' => $mail]
    );

  }

  public function lastMail()
  {
    return $users = DB::table($this->_table)->where('id','=',$this->lastId())->first();
  }

  private function lastId()
  {
    return DB::getPdo()->lastInsertId();
  }
}
