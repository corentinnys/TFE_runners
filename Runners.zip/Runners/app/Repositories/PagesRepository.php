<?php


namespace App\Repositories;



/**
 *
 */
class PagesRepository extends repository
{

  protected $table;

  public function __construct($table)
  {
    $this->table = $table
  }
}
