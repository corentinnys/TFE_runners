<?php
namespace App\Repositories;
use DB;


/**
 *
 */
class UserRepository extends repository
{

private $_table = 'users';

  public function findOneByUserName($username)
  {
    return $data = DB::table($this->_table)
                ->where('name','=',$username)
                ->first();
  }
  /**
 	 * Méthode qui verifie si l'utilisateur fait partie du comite
 	 *
 	 * @param string $mail
 	 * @return void
	 */


  public function verifComite($mail)
  {

    return ($this->findOneByParam('email',$mail)->isComite == 1)?true:false;

  }


  public function AllChamps()
  {
    DB::getSchemaBuilder()->getColumnListing($this->_table)
  }

  /**
 	 * Méthode qui fait une requete dans la base de donne en fonction du mail
 	 *
 	 * @param string $mail
 	 * @return void
	 */

  private function isComite($mail)
  {
    return DB::table($this->_table)
            ->where('email','=',$mail)
            ->first();
  }

  private function findOneByParam($champs,$param)
  {
    return DB::table($this->_table)
            ->where($champs,'=',$param)
            ->first();
  }

  public function verifEntraineneur()
  {
      return DB::table($this->_table)->where('isJoueur','=', 1)->first();
  }

  public function lastUser()
  {
    return DB::table($this->_table)->where('id','=', $this->lastId())->first();
  }
  private function lastId()
  {
    return DB::table($this->_table)->max('id');
  }
}
