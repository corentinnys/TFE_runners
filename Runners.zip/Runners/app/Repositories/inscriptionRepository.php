<?php
namespace App\Repositories;
use Illuminate\Support\Facades\Input;
use DB;


/**
 *
 */
class inscriptionRepository extends repository
{

    private $_user ;

    private $_alphabet = "ABCDEFGHIJKLMOPQRSTUVXWYZ0123456789";
    private $_motAléatoire;


    public function save($request)
    {
      $this->_user = new \App\Models\User ;
      $this->_user->name = $request->lastname;
      $this->_user->email = $request->email;
      $this->_user->password = $this->generatePassword(10);
      $test =$this->fileUpload($request);
      dd($test);
      $this->_user->save();
    }


    public function fileUpload($request)
    {
      /*var_dump($request->hasFile());*/

      $imageName = request()->photo->getClientOriginalExtension();

       request()->image->move(public_path('images'), $imageName);
   return true;
 }




    public function generatePassword($number)
    {
      for ($i=0; $i <$number ; $i++) {
        $aleatoire = rand(0,strlen($this->_alphabet));
        if($aleatoire == strlen($this->_alphabet))
        {
          $this->_motAléatoire =$this->_alphabet[$aleatoire-1].$this->_motAléatoire;
        }
        else
        {
          $this->_motAléatoire =$this->_alphabet[$aleatoire-1].$this->_motAléatoire;
        }

    }
      return md5($this->_motAléatoire);
  }
}
