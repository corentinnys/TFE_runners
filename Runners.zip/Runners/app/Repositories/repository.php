<?php


namespace App\Repositories;



/**
 *
 */
class repository
{

  protected $table;



}
